SISTEMA — REGISTRADURÍA MUNICIPAL DE NOBSA
Vistas JSP

ESTRUCTURA:
  WEB-INF/vistas/votante/
    index.jsp             Página pública: cédula + captcha
    resultadoConsulta.jsp Resultado con 3 casos (mesa asignada / sin mesa / no encontrado)

  WEB-INF/vistas/admin/
    adminLayout.jsp       Layout base: sidebar + topbar (incluir en cada vista admin)
    dashboard.jsp         Panel de inicio con estadísticas y alertas

    ciudadanos/listado.jsp  CRUD completo (modal crear/editar, confirm eliminar)
    documentos/listado.jsp  Expedir + cambio de estado (modal)
    zonas/listado.jsp       CRUD zonas de votación (modal)
    mesas/listado.jsp       CRUD mesas (modal + estadísticas rápidas)

DEPENDENCIAS JSP (pom.xml):
  jakarta.servlet.jsp.jstl-api:3.0.0
  jakarta.servlet.jsp.jstl:3.0.1 (glassfish.web)
  Font Awesome 6.5 (CDN incluido en cada JSP)
  Google Fonts: Source Serif 4 + IBM Plex Sans

FLUJO:
  Votante: / → index.jsp → GET /consulta-mesa → resultadoConsulta.jsp
  Admin:  /admin/** → adminLayout.jsp (sidebar) + módulo específico

Motor Usado: Sql Server Es más fácil porque es un programa muy visual e intuitivo ya que permite gestionar todo con clics y ventanas en lugar de códigos complicados. 
Además, se conecta de forma muy natural con NetBeans y es más "amigable" al escribir consultas, ya que no te da errores si mezclas mayúsculas y minúsculas, facilitándote mucho el trabajo si estás empezando.

ACCESO ADMIN: /admin/login  →  usuario: admin  |  contraseña: sena2025
FLUJO COMPLETO: / (landing) → consulta pública ó → /admin/login → dashboard
