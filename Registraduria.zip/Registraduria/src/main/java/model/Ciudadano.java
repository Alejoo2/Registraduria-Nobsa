package model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Ciudadano {

    private int id;
    private String numeroDocumento;
    private String nombres;
    private String apellidos;
    private LocalDate fechaNacimiento;
    private String veredaBarrio;
    private String telefono;
    private String correo;
    private LocalDateTime fechaRegistro;
    private Integer idMesa; 

    public Ciudadano() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String v) {
        this.numeroDocumento = v;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String v) {
        this.nombres = v;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String v) {
        this.apellidos = v;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate v) {
        this.fechaNacimiento = v;
    }

    public String getVeredaBarrio() {
        return veredaBarrio;
    }

    public void setVeredaBarrio(String v) {
        this.veredaBarrio = v;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String v) {
        this.telefono = v;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String v) {
        this.correo = v;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDateTime v) {
        this.fechaRegistro = v;
    }

    public Integer getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(Integer v) {
        this.idMesa = v;
    }
}
