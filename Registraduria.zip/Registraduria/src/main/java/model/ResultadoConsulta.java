package model;

public class ResultadoConsulta {

    private String nombres, apellidos, numeroDocumento;
    private String ciudad, codigoDane;
    private String nombreZona, puestoVotacion, direccion;
    private int numeroMesa, capacidad;

    public ResultadoConsulta() {
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String v) {
        this.nombres = v;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String v) {
        this.apellidos = v;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String v) {
        this.numeroDocumento = v;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String v) {
        this.ciudad = v;
    }

    public String getCodigoDane() {
        return codigoDane;
    }

    public void setCodigoDane(String v) {
        this.codigoDane = v;
    }

    public String getNombreZona() {
        return nombreZona;
    }

    public void setNombreZona(String v) {
        this.nombreZona = v;
    }

    public String getPuestoVotacion() {
        return puestoVotacion;
    }

    public void setPuestoVotacion(String v) {
        this.puestoVotacion = v;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String v) {
        this.direccion = v;
    }

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public void setNumeroMesa(int v) {
        this.numeroMesa = v;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int v) {
        this.capacidad = v;
    }
}
