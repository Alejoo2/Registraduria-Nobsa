package dao;

import config.ConexionDB;
import model.Ciudadano;
import java.sql.*;
import java.util.*;

public class CiudadanoDAOImpl implements CiudadanoDAO {

    @Override
    public void insertar(Ciudadano c) throws Exception {
        String sql = "INSERT INTO ciudadanos "
                + "(numero_documento, nombres, apellidos, fecha_nacimiento, "
                + " vereda_barrio, telefono, correo, id_mesa) "
                + "VALUES (?,?,?,?,?,?,?,?)";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNumeroDocumento());
            ps.setString(2, c.getNombres());
            ps.setString(3, c.getApellidos());
            ps.setDate(4, java.sql.Date.valueOf(c.getFechaNacimiento()));
            ps.setString(5, c.getVeredaBarrio());
            ps.setString(6, c.getTelefono());
            ps.setString(7, c.getCorreo());
            if (c.getIdMesa() != null) {
                ps.setInt(8, c.getIdMesa());
            } else {
                ps.setNull(8, Types.INTEGER);
            }
            ps.executeUpdate();
        }
    }

    @Override
    public List<Ciudadano> listarTodos() throws Exception {
        List<Ciudadano> lista = new ArrayList<>();
        String sql = "SELECT * FROM ciudadanos ORDER BY apellidos, nombres";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    @Override
    public List<Ciudadano> listarUltimos(int limite) throws Exception {
        List<Ciudadano> lista = new ArrayList<>();
        String sql = "SELECT TOP (?) * FROM ciudadanos ORDER BY fecha_registro DESC, id DESC";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, limite);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public Ciudadano buscarPorDocumento(String numDoc) throws Exception {
        String sql = "SELECT * FROM ciudadanos WHERE numero_documento = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, numDoc);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public Ciudadano buscarPorId(int id) throws Exception {
        String sql = "SELECT * FROM ciudadanos WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public void actualizar(Ciudadano c) throws Exception {
        String sql = "UPDATE ciudadanos SET nombres=?, apellidos=?, "
                + "fecha_nacimiento=?, vereda_barrio=?, telefono=?, correo=?, id_mesa=? "
                + "WHERE id=?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNombres());
            ps.setString(2, c.getApellidos());
            ps.setDate(3, java.sql.Date.valueOf(c.getFechaNacimiento()));
            ps.setString(4, c.getVeredaBarrio());
            ps.setString(5, c.getTelefono());
            ps.setString(6, c.getCorreo());
            if (c.getIdMesa() != null) {
                ps.setInt(7, c.getIdMesa());
            } else {
                ps.setNull(7, Types.INTEGER);
            }
            ps.setInt(8, c.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws Exception {
        String sql = "DELETE FROM ciudadanos WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public boolean tieneDocs(int idCiudadano) throws Exception {
        String sql = "SELECT COUNT(*) FROM documentos_expedidos WHERE id_ciudadano = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCiudadano);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    private Ciudadano mapear(ResultSet rs) throws SQLException {
        Ciudadano c = new Ciudadano();
        c.setId(rs.getInt("id"));
        c.setNumeroDocumento(rs.getString("numero_documento"));
        c.setNombres(rs.getString("nombres"));
        c.setApellidos(rs.getString("apellidos"));
        var fn = rs.getDate("fecha_nacimiento");
        if (fn != null) {
            c.setFechaNacimiento(fn.toLocalDate());
        }
        c.setVeredaBarrio(rs.getString("vereda_barrio"));
        c.setTelefono(rs.getString("telefono"));
        c.setCorreo(rs.getString("correo"));
        Timestamp ts = rs.getTimestamp("fecha_registro");
        if (ts != null) {
            c.setFechaRegistro(ts.toLocalDateTime());
        }
        int mesa = rs.getInt("id_mesa");
        if (!rs.wasNull()) {
            c.setIdMesa(mesa);
        }
        return c;
    }
}
