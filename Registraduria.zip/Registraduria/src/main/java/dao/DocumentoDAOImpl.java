package dao;

import config.ConexionDB;
import model.DocumentoExpedido;
import java.sql.*;
import java.util.*;

public class DocumentoDAOImpl implements DocumentoDAO {

    @Override
    public void insertar(DocumentoExpedido d) throws Exception {
        String sql = "INSERT INTO documentos_expedidos "
                + "(id_ciudadano, tipo_documento, numero_serie, fecha_expedicion, "
                + "fecha_vencimiento, estado, observaciones) "
                + "VALUES (?,?,?,?,?,?,?)";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, d.getIdCiudadano());
            ps.setString(2, d.getTipoDocumento());
            ps.setString(3, d.getNumeroSerie());
            ps.setDate(4, java.sql.Date.valueOf(d.getFechaExpedicion()));

            if (d.getFechaVencimiento() != null) {
                ps.setDate(5, java.sql.Date.valueOf(d.getFechaVencimiento()));
            } else {
                ps.setNull(5, Types.DATE);
            }

            ps.setString(6, d.getEstado());
            ps.setString(7, d.getObservaciones());
            ps.executeUpdate();
        }
    }

    @Override
    public List<DocumentoExpedido> listarTodos() throws Exception {
        List<DocumentoExpedido> lista = new ArrayList<>();

        // 👇 JOIN con ciudadanos para obtener nombre y documento
        String sql = "SELECT d.*, c.nombres + ' ' + c.apellidos AS nombre_completo, "
                + "c.numero_documento "
                + "FROM documentos_expedidos d "
                + "INNER JOIN ciudadanos c ON d.id_ciudadano = c.id "
                + "ORDER BY d.fecha_expedicion DESC, d.numero_serie";

        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                DocumentoExpedido doc = new DocumentoExpedido();
                doc.setId(rs.getInt("id"));
                doc.setIdCiudadano(rs.getInt("id_ciudadano"));
                doc.setTipoDocumento(rs.getString("tipo_documento"));
                doc.setNumeroSerie(rs.getString("numero_serie"));

                // LocalDate desde java.sql.Date
                java.sql.Date fe = rs.getDate("fecha_expedicion");
                if (fe != null) {
                    doc.setFechaExpedicion(fe.toLocalDate());
                }

                java.sql.Date fv = rs.getDate("fecha_vencimiento");
                if (fv != null) {
                    doc.setFechaVencimiento(fv.toLocalDate());
                }

                doc.setEstado(rs.getString("estado"));
                doc.setObservaciones(rs.getString("observaciones"));

                // 👇 Datos del JOIN (clave para el listado)
                doc.setNombreCiudadano(rs.getString("nombre_completo"));
                doc.setNumeroDocumentoCiudadano(rs.getString("numero_documento"));

                lista.add(doc);
            }
        }
        return lista;
    }

    @Override
    public List<DocumentoExpedido> listarPorCiudadano(int idCiudadano) throws Exception {
        List<DocumentoExpedido> lista = new ArrayList<>();

        String sql = "SELECT d.*, c.nombres + ' ' + c.apellidos AS nombre_completo, "
                + "c.numero_documento "
                + "FROM documentos_expedidos d "
                + "INNER JOIN ciudadanos c ON d.id_ciudadano = c.id "
                + "WHERE d.id_ciudadano = ? "
                + "ORDER BY d.fecha_expedicion DESC";

        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCiudadano);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    DocumentoExpedido doc = new DocumentoExpedido();
                    doc.setId(rs.getInt("id"));
                    doc.setIdCiudadano(rs.getInt("id_ciudadano"));
                    doc.setTipoDocumento(rs.getString("tipo_documento"));
                    doc.setNumeroSerie(rs.getString("numero_serie"));

                    java.sql.Date fe = rs.getDate("fecha_expedicion");
                    if (fe != null) {
                        doc.setFechaExpedicion(fe.toLocalDate());
                    }

                    java.sql.Date fv = rs.getDate("fecha_vencimiento");
                    if (fv != null) {
                        doc.setFechaVencimiento(fv.toLocalDate());
                    }

                    doc.setEstado(rs.getString("estado"));
                    doc.setObservaciones(rs.getString("observaciones"));

                    doc.setNombreCiudadano(rs.getString("nombre_completo"));
                    doc.setNumeroDocumentoCiudadano(rs.getString("numero_documento"));

                    lista.add(doc);
                }
            }
        }
        return lista;
    }

    @Override
    public void cambiarEstado(int id, String nuevoEstado) throws Exception {
        String sql = "UPDATE documentos_expedidos SET estado = ? WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nuevoEstado);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws Exception {
        String sql = "DELETE FROM documentos_expedidos WHERE id = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public DocumentoExpedido buscarPorId(int id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
