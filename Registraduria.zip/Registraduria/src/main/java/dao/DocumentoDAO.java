package dao;

import model.DocumentoExpedido;
import java.util.List;

public interface DocumentoDAO {

    void insertar(DocumentoExpedido d) throws Exception;

    List<DocumentoExpedido> listarPorCiudadano(int idCiudadano) throws Exception;

    List<DocumentoExpedido> listarTodos() throws Exception;

    DocumentoExpedido buscarPorId(int id) throws Exception;

    void cambiarEstado(int id, String nuevoEstado) throws Exception;

    void eliminar(int id) throws Exception;
}
