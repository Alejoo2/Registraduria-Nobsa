package dao;

import model.Ciudadano;
import java.util.List;

public interface CiudadanoDAO {

    void insertar(Ciudadano c) throws Exception;

    List<Ciudadano> listarTodos() throws Exception;

    List<Ciudadano> listarUltimos(int limite) throws Exception;

    Ciudadano buscarPorDocumento(String numeroDocumento) throws Exception;

    Ciudadano buscarPorId(int id) throws Exception;

    void actualizar(Ciudadano c) throws Exception;

    void eliminar(int id) throws Exception;

    boolean tieneDocs(int idCiudadano) throws Exception;
}