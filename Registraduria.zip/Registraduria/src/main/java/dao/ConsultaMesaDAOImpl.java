package dao;

import config.ConexionDB;
import model.ResultadoConsulta;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConsultaMesaDAOImpl implements ConsultaMesaDAO {

    @Override
    public ResultadoConsulta buscarPorDocumento(String numDocumento) throws Exception {
        String sql
                = "SELECT c.nombres, c.apellidos, c.numero_documento, "
                + "  ci.nombre AS ciudad, ci.codigo_dane, "
                + "  z.nombre_zona, z.puesto_votacion, z.direccion, "
                + "  m.numero_mesa, m.capacidad "
                + "FROM ciudadanos c "
                + "INNER JOIN mesas_votacion m   ON c.id_mesa  = m.id "
                + "INNER JOIN zonas_votacion z   ON m.id_zona  = z.id "
                + "INNER JOIN ciudades       ci  ON z.id_ciudad = ci.id "
                + "WHERE c.numero_documento = ?";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, numDocumento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ResultadoConsulta r = new ResultadoConsulta();
                    r.setNombres(rs.getString("nombres"));
                    r.setApellidos(rs.getString("apellidos"));
                    r.setNumeroDocumento(rs.getString("numero_documento"));
                    r.setCiudad(rs.getString("ciudad"));
                    r.setCodigoDane(rs.getString("codigo_dane"));
                    r.setNombreZona(rs.getString("nombre_zona"));
                    r.setPuestoVotacion(rs.getString("puesto_votacion"));
                    r.setDireccion(rs.getString("direccion"));
                    r.setNumeroMesa(rs.getInt("numero_mesa"));
                    r.setCapacidad(rs.getInt("capacidad"));
                    return r;
                }
                return null;
            }
        }
    }

    @Override
    public List<String[]> listarMesasPorZona(int idZona) throws Exception {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT m.numero_mesa, m.capacidad, z.nombre_zona, z.puesto_votacion "
                + "FROM mesas_votacion m "
                + "INNER JOIN zonas_votacion z ON m.id_zona = z.id "
                + "WHERE m.id_zona = ? "
                + "ORDER BY m.numero_mesa";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idZona);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new String[]{
                        String.valueOf(rs.getInt("numero_mesa")),
                        String.valueOf(rs.getInt("capacidad")),
                        rs.getString("nombre_zona"),
                        rs.getString("puesto_votacion")
                    });
                }
            }
        }
        return lista;
    }

    @Override
    public List<String[]> listarZonasPorCiudad(String nombreODane) throws Exception {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT z.id, z.nombre_zona, z.puesto_votacion, z.direccion, ci.nombre AS ciudad "
                + "FROM zonas_votacion z "
                + "INNER JOIN ciudades ci ON z.id_ciudad = ci.id "
                + "WHERE ci.nombre = ? OR ci.codigo_dane = ? "
                + "ORDER BY z.nombre_zona";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombreODane);
            ps.setString(2, nombreODane);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new String[]{
                        String.valueOf(rs.getInt("id")),
                        rs.getString("nombre_zona"),
                        rs.getString("puesto_votacion"),
                        rs.getString("direccion"),
                        rs.getString("ciudad")
                    });
                }
            }
        }
        return lista;
    }
}
