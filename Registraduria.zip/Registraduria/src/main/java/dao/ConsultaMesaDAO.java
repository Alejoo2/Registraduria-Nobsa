package dao;

import model.ResultadoConsulta;
import java.util.List;

public interface ConsultaMesaDAO {

    ResultadoConsulta buscarPorDocumento(String numDocumento) throws Exception;

    List<String[]> listarMesasPorZona(int idZona) throws Exception;

    List<String[]> listarZonasPorCiudad(String nombreODane) throws Exception;
}
