package config;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionDB {

    private static final String URL
            = "jdbc:sqlserver://localhost:1433;databaseName=registraduria_nobsa;encrypt=true;trustServerCertificate=true;";

    private static final String USER = "sa";
    private static final String PASSWORD = "sena2025";

    public static Connection obtenerConexion() throws Exception {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
