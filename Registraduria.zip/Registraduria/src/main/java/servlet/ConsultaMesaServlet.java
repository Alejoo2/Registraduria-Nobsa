package servlet;

import dao.CiudadanoDAO;
import dao.CiudadanoDAOImpl;
import dao.ConsultaMesaDAO;
import dao.ConsultaMesaDAOImpl;
import model.Ciudadano;
import model.ResultadoConsulta;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.json.JSONObject;  // ← Del dependency org.json

@WebServlet(name = "ConsultaMesaServlet", urlPatterns = {"/consulta-mesa"})
public class ConsultaMesaServlet extends HttpServlet {

    private final ConsultaMesaDAO mesaDao = new ConsultaMesaDAOImpl();
    private final CiudadanoDAO ciudadanoDao = new CiudadanoDAOImpl();

    private static final String RECAPTCHA_SECRET_KEY = "6Lek_sIsAAAAAIwPP5FvWOFTys4g8KGFS3sGsG7L";
    private static final String RECAPTCHA_VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/vistas/votante/index.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String documento = trim(req.getParameter("documento"));
        String recaptchaResponse = req.getParameter("g-recaptcha-response");

        if (recaptchaResponse == null || recaptchaResponse.isEmpty()) {
            req.setAttribute("errorCaptcha", "Por favor completa la verificación de seguridad.");
            req.setAttribute("documentoPrevio", documento);
            req.getRequestDispatcher("/WEB-INF/vistas/votante/index.jsp").forward(req, resp);
            return;
        }

        boolean captchaValido = verificarRecaptcha(recaptchaResponse);

        if (!captchaValido) {
            req.setAttribute("errorCaptcha", "La verificación de seguridad falló. Intente de nuevo.");
            req.setAttribute("documentoPrevio", documento);
            req.getRequestDispatcher("/WEB-INF/vistas/votante/index.jsp").forward(req, resp);
            return;
        }

        if (documento == null || documento.isEmpty()) {
            req.setAttribute("errorCaptcha", "Ingrese el número de documento.");
            req.getRequestDispatcher("/WEB-INF/vistas/votante/index.jsp").forward(req, resp);
            return;
        }

        try {
            ResultadoConsulta resultado = mesaDao.buscarPorDocumento(documento);
            if (resultado != null) {
                req.setAttribute("resultado", resultado);
            } else {
                Ciudadano ciudadano = ciudadanoDao.buscarPorDocumento(documento);
                if (ciudadano != null) {
                    req.setAttribute("ciudadanoSinMesa", ciudadano);
                } else {
                    req.setAttribute("noEncontrado", Boolean.TRUE);
                    req.setAttribute("documentoBuscado", documento);
                }
            }
            req.getRequestDispatcher("/WEB-INF/vistas/votante/resultadoConsulta.jsp").forward(req, resp);
        } catch (Exception e) {
            throw new ServletException("Error en ConsultaMesaServlet: " + e.getMessage(), e);
        }
    }

    private boolean verificarRecaptcha(String recaptchaResponse) {
        try {
            URL url = new URL(RECAPTCHA_VERIFY_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            String params = "secret=" + URLEncoder.encode(RECAPTCHA_SECRET_KEY, StandardCharsets.UTF_8)
                    + "&response=" + URLEncoder.encode(recaptchaResponse, StandardCharsets.UTF_8);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = params.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            int status = conn.getResponseCode();
            BufferedReader br;

            if (status >= 200 && status < 300) {
                br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            } else {
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            }

            StringBuilder response = new StringBuilder();
            String responseLine;

            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            br.close();
            conn.disconnect();

            JSONObject jsonResponse = new JSONObject(response.toString());
            return jsonResponse.getBoolean("success");

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private String trim(String s) {
        return s == null ? null : s.trim();
    }
}
