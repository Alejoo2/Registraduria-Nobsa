package servlet;

import config.ConexionDB;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "ZonaServlet", urlPatterns = {"/admin/zonas"})
public class ZonaServlet extends HttpServlet {

    private List<Map<String, Object>> listarZonas() throws Exception {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT z.id, z.nombre_zona, z.puesto_votacion, z.direccion, "
                + "  ci.nombre AS ciudad, ci.id AS id_ciudad, "
                + "  (SELECT COUNT(*) FROM mesas_votacion m WHERE m.id_zona = z.id) AS num_mesas "
                + "FROM zonas_votacion z "
                + "INNER JOIN ciudades ci ON z.id_ciudad = ci.id "
                + "ORDER BY ci.nombre, z.nombre_zona";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("id", rs.getInt("id"));
                row.put("nombreZona", rs.getString("nombre_zona"));
                row.put("puestoVotacion", rs.getString("puesto_votacion"));
                row.put("direccion", rs.getString("direccion"));
                row.put("ciudad", rs.getString("ciudad"));
                row.put("idCiudad", rs.getInt("id_ciudad"));
                row.put("numeroMesas", rs.getInt("num_mesas"));
                lista.add(row);
            }
        }
        return lista;
    }

    private List<Map<String, Object>> listarCiudades() throws Exception {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, codigo_dane FROM ciudades ORDER BY nombre";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("id", rs.getInt("id"));
                row.put("nombre", rs.getString("nombre"));
                row.put("codigoDane", rs.getString("codigo_dane"));
                lista.add(row);
            }
        }
        return lista;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("eliminar".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM zonas_votacion WHERE id = ?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                resp.sendRedirect(req.getContextPath() + "/admin/zonas?ok=eliminado");
            } else {
                req.setAttribute("zonas", listarZonas());
                req.setAttribute("ciudades", listarCiudades());
                if ("guardado".equals(req.getParameter("ok"))) {
                    req.setAttribute("successMsg", "Zona guardada correctamente.");
                }
                if ("eliminado".equals(req.getParameter("ok"))) {
                    req.setAttribute("successMsg", "Zona eliminada correctamente.");
                }
                req.getRequestDispatcher("/WEB-INF/vistas/admin/zonas/listado.jsp")
                        .forward(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException("Error en ZonaServlet: " + e.getMessage(), e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");

        // Manejar eliminación por POST (mejor práctica)
        if ("eliminar".equals(action)) {
            try {
                int id = Integer.parseInt(req.getParameter("id"));
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM zonas_votacion WHERE id = ?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                resp.sendRedirect(req.getContextPath() + "/admin/zonas?ok=eliminado");
                return;
            } catch (Exception e) {
                throw new ServletException("Error eliminando zona: " + e.getMessage(), e);
            }
        }

        try {
            String idParam = req.getParameter("id");
            int idCiudad = Integer.parseInt(req.getParameter("idCiudad"));
            String nombre = req.getParameter("nombreZona");
            String puesto = req.getParameter("puestoVotacion");
            String dir = req.getParameter("direccion");

            if (idParam == null || idParam.isEmpty()) {
                String sql = "INSERT INTO zonas_votacion (id_ciudad, nombre_zona, puesto_votacion, direccion) "
                        + "VALUES (?, ?, ?, ?)";
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, idCiudad);
                    ps.setString(2, nombre);
                    ps.setString(3, puesto);
                    ps.setString(4, dir);
                    ps.executeUpdate();
                }
            } else {
                String sql = "UPDATE zonas_votacion SET id_ciudad=?, nombre_zona=?, puesto_votacion=?, direccion=? WHERE id=?";
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, idCiudad);
                    ps.setString(2, nombre);
                    ps.setString(3, puesto);
                    ps.setString(4, dir);
                    ps.setInt(5, Integer.parseInt(idParam));
                    ps.executeUpdate();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/zonas?ok=guardado");
        } catch (Exception e) {
            throw new ServletException("Error guardando zona: " + e.getMessage(), e);
        }
    }
}
