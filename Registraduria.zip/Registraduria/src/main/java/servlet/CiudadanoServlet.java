package servlet;

import config.ConexionDB;
import dao.CiudadanoDAO;
import dao.CiudadanoDAOImpl;
import model.Ciudadano;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "CiudadanoServlet", urlPatterns = {"/admin/ciudadanos"})
public class CiudadanoServlet extends HttpServlet {

    private final CiudadanoDAO dao = new CiudadanoDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try {
            if ("eliminar".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                if (dao.tieneDocs(id)) {
                    req.setAttribute("ciudadanos", dao.listarTodos());
                    req.setAttribute("mesas", listarMesas());
                    req.setAttribute("errorMsg",
                            "No se puede eliminar: el ciudadano tiene documentos expedidos asociados.");
                    req.getRequestDispatcher("/WEB-INF/vistas/admin/ciudadanos/listado.jsp")
                            .forward(req, resp);
                    return;
                }
                dao.eliminar(id);
                resp.sendRedirect(req.getContextPath() + "/admin/ciudadanos?ok=eliminado");

            } else if ("buscar".equals(action)) {
                String doc = req.getParameter("documento");
                Ciudadano c = dao.buscarPorDocumento(doc);
                req.setAttribute("resultadoBusqueda", c);
                req.setAttribute("documentoBuscado", doc);
                req.setAttribute("ciudadanos", dao.listarTodos());
                req.setAttribute("mesas", listarMesas());
                req.getRequestDispatcher("/WEB-INF/vistas/admin/ciudadanos/listado.jsp")
                        .forward(req, resp);

            } else {
                // Listar todos
                req.setAttribute("ciudadanos", dao.listarTodos());
                req.setAttribute("mesas", listarMesas());
                // Mensajes flash
                if ("eliminado".equals(req.getParameter("ok"))) {
                    req.setAttribute("successMsg", "Ciudadano eliminado correctamente.");
                }
                if ("guardado".equals(req.getParameter("ok"))) {
                    req.setAttribute("successMsg", "Ciudadano guardado correctamente.");
                }
                req.getRequestDispatcher("/WEB-INF/vistas/admin/ciudadanos/listado.jsp")
                        .forward(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException("Error en CiudadanoServlet: " + e.getMessage(), e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        try {
            Ciudadano c = new Ciudadano();

            String idParam = req.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                c.setId(Integer.parseInt(idParam));
            }

            // Nombres de campo en camelCase (del modal)
            c.setNumeroDocumento(req.getParameter("numeroDocumento"));
            c.setNombres(req.getParameter("nombres"));
            c.setApellidos(req.getParameter("apellidos"));

            String fn = req.getParameter("fechaNacimiento");
            if (fn != null && !fn.isEmpty()) {
                c.setFechaNacimiento(LocalDate.parse(fn));
            }

            c.setVeredaBarrio(req.getParameter("veredaBarrio"));
            c.setTelefono(req.getParameter("telefono"));
            c.setCorreo(req.getParameter("correo"));

            String mesaParam = req.getParameter("idMesa");
            if (mesaParam != null && !mesaParam.isEmpty()) {
                c.setIdMesa(Integer.parseInt(mesaParam));
            }

            if (c.getId() == 0) {
                dao.insertar(c);
            } else {
                dao.actualizar(c);
            }

            resp.sendRedirect(req.getContextPath() + "/admin/ciudadanos?ok=guardado");

        } catch (Exception e) {
            throw new ServletException("Error guardando ciudadano: " + e.getMessage(), e);
        }
    }

    /**
     * Devuelve lista de mesas para el select del modal.
     */
    private List<Map<String, Object>> listarMesas() throws Exception {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT m.id, m.numero_mesa, m.capacidad, z.nombre_zona "
                + "FROM mesas_votacion m "
                + "INNER JOIN zonas_votacion z ON m.id_zona = z.id "
                + "ORDER BY z.nombre_zona, m.numero_mesa";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("id", rs.getInt("id"));
                row.put("numeroMesa", rs.getInt("numero_mesa"));
                row.put("capacidad", rs.getInt("capacidad"));
                row.put("nombreZona", rs.getString("nombre_zona"));
                lista.add(row);
            }
        }
        return lista;
    }
}
