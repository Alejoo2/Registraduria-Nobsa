package servlet;

import config.ConexionDB;
import dao.CiudadanoDAOImpl;
import model.Ciudadano;
import java.io.IOException;
import java.sql.*;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "DashboardServlet", urlPatterns = {"/admin/dashboard", "/admin"})
public class DashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            // ── Conteos principales ────────────────────────
            String sqlCounts =
                "SELECT " +
                "  (SELECT COUNT(*) FROM ciudadanos)                              AS total_ciudadanos, " +
                "  (SELECT COUNT(*) FROM documentos_expedidos)                    AS total_documentos, " +
                "  (SELECT COUNT(*) FROM zonas_votacion)                          AS total_zonas, " +
                "  (SELECT COUNT(*) FROM mesas_votacion)                          AS total_mesas, " +
                "  (SELECT COUNT(*) FROM ciudadanos WHERE id_mesa IS NULL)        AS sin_mesa, " +
                "  (SELECT COUNT(*) FROM documentos_expedidos WHERE estado='vencido') AS doc_vencidos, " +
                "  (SELECT COUNT(*) FROM documentos_expedidos " +
                "     WHERE fecha_vencimiento IS NOT NULL " +
                "       AND fecha_vencimiento BETWEEN GETDATE() AND DATEADD(DAY,30,GETDATE())) AS prox_vencer";

            try (Connection con = ConexionDB.obtenerConexion();
                 PreparedStatement ps = con.prepareStatement(sqlCounts);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    req.setAttribute("totalCiudadanos",    rs.getInt("total_ciudadanos"));
                    req.setAttribute("totalDocumentos",    rs.getInt("total_documentos"));
                    req.setAttribute("totalZonas",         rs.getInt("total_zonas"));
                    req.setAttribute("totalMesas",         rs.getInt("total_mesas"));
                    req.setAttribute("ciudadanosSinMesa",  rs.getInt("sin_mesa"));
                    req.setAttribute("documentosVencidos", rs.getInt("doc_vencidos"));
                    req.setAttribute("documentosProxVencer", rs.getInt("prox_vencer"));
                }
            }

            // ── Últimos 5 ciudadanos ────────────────────
            List<Ciudadano> ultimos = new CiudadanoDAOImpl().listarUltimos(5);
            req.setAttribute("ultimosCiudadanos", ultimos);

        } catch (Exception e) {
            // Si hay error de BD, continuar con atributos vacíos
            req.setAttribute("totalCiudadanos", 0);
            req.setAttribute("totalDocumentos", 0);
            req.setAttribute("totalZonas", 0);
            req.setAttribute("totalMesas", 0);
        }

        req.getRequestDispatcher("/WEB-INF/vistas/admin/dashboard.jsp").forward(req, resp);
    }
}
