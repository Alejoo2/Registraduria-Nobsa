package servlet;

import dao.CiudadanoDAO;
import dao.CiudadanoDAOImpl;
import dao.DocumentoDAO;
import dao.DocumentoDAOImpl;
import model.Ciudadano;
import model.DocumentoExpedido;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "DocumentoServlet", urlPatterns = {"/admin/documentos"})
public class DocumentoServlet extends HttpServlet {

    private final DocumentoDAO dao = new DocumentoDAOImpl();
    private final CiudadanoDAO ciudadanoDao = new CiudadanoDAOImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");

        try {
            if ("porCiudadano".equals(action) || req.getParameter("idCiudadano") != null) {
                int idC = Integer.parseInt(
                        req.getParameter("idCiudadano") != null
                        ? req.getParameter("idCiudadano")
                        : req.getParameter("id"));
                List<DocumentoExpedido> docs = dao.listarPorCiudadano(idC);
                Ciudadano ciudadano = ciudadanoDao.buscarPorId(idC);
                req.setAttribute("documentos", docs);
                req.setAttribute("filtroCiudadano", ciudadano);
                req.setAttribute("ciudadanos", ciudadanoDao.listarTodos());
                req.getRequestDispatcher("/WEB-INF/vistas/admin/documentos/listado.jsp")
                        .forward(req, resp);

            } else if ("cambiarEstado".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                String nuevoEstado = req.getParameter("estado");
                dao.cambiarEstado(id, nuevoEstado);
                resp.sendRedirect(req.getContextPath() + "/admin/documentos?ok=estado");

            } else if ("eliminar".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                dao.eliminar(id);
                resp.sendRedirect(req.getContextPath() + "/admin/documentos?ok=eliminado");

            } else {
                List<DocumentoExpedido> docs = dao.listarTodos();
                req.setAttribute("documentos", docs);
                req.setAttribute("ciudadanos", ciudadanoDao.listarTodos());
                if ("estado".equals(req.getParameter("ok"))) {
                    req.setAttribute("successMsg", "Estado actualizado correctamente.");
                }
                if ("guardado".equals(req.getParameter("ok"))) {
                    req.setAttribute("successMsg", "Documento expedido correctamente.");
                }
                req.getRequestDispatcher("/WEB-INF/vistas/admin/documentos/listado.jsp")
                        .forward(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException("Error en DocumentoServlet: " + e.getMessage(), e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");

        try {
            if ("cambiarEstado".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                String nuevoEstado = req.getParameter("estado");
                dao.cambiarEstado(id, nuevoEstado);
                resp.sendRedirect(req.getContextPath() + "/admin/documentos?ok=estado");
                return;
            }

            // Insertar nuevo documento
            DocumentoExpedido d = new DocumentoExpedido();

            String idCiudadanoParam = req.getParameter("idCiudadano");
            if (idCiudadanoParam == null || idCiudadanoParam.isEmpty()) {
                idCiudadanoParam = req.getParameter("id_ciudadano");
            }
            d.setIdCiudadano(Integer.parseInt(idCiudadanoParam));
            d.setTipoDocumento(req.getParameter("tipoDocumento") != null
                    ? req.getParameter("tipoDocumento")
                    : req.getParameter("tipo_documento"));
            d.setNumeroSerie(req.getParameter("numeroSerie") != null
                    ? req.getParameter("numeroSerie")
                    : req.getParameter("numero_serie"));

            String fe = req.getParameter("fechaExpedicion");
            if (fe == null || fe.isEmpty()) {
                fe = req.getParameter("fecha_expedicion");
            }
            d.setFechaExpedicion(LocalDate.parse(fe));

            String fv = req.getParameter("fechaVencimiento");
            if (fv == null || fv.isEmpty()) {
                fv = req.getParameter("fecha_vencimiento");
            }
            if (fv != null && !fv.isEmpty()) {
                d.setFechaVencimiento(LocalDate.parse(fv));
            }

            String estado = req.getParameter("estado");
            d.setEstado((estado != null && !estado.isEmpty()) ? estado : "vigente");
            d.setObservaciones(req.getParameter("observaciones"));

            dao.insertar(d);
            resp.sendRedirect(req.getContextPath() + "/admin/documentos?ok=guardado");

        } catch (Exception e) {
            throw new ServletException("Error registrando documento: " + e.getMessage(), e);
        }
    }
}
