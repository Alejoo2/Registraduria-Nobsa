package servlet;

import config.ConexionDB;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "MesaServlet", urlPatterns = {"/admin/mesas"})
public class MesaServlet extends HttpServlet {

    private List<Map<String, Object>> listarMesas() throws Exception {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT m.id, m.numero_mesa, m.capacidad, "
                + "  z.nombre_zona, z.puesto_votacion, z.id AS id_zona, "
                + "  ci.nombre AS ciudad, "
                + "  (SELECT COUNT(*) FROM ciudadanos c WHERE c.id_mesa = m.id) AS inscritos "
                + "FROM mesas_votacion m "
                + "INNER JOIN zonas_votacion z ON m.id_zona = z.id "
                + "INNER JOIN ciudades ci ON z.id_ciudad = ci.id "
                + "ORDER BY ci.nombre, z.nombre_zona, m.numero_mesa";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int cap = rs.getInt("capacidad");
                int ins = rs.getInt("inscritos");
                int pct = cap > 0 ? (int) Math.round((ins * 100.0) / cap) : 0;
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("id", rs.getInt("id"));
                row.put("numeroMesa", rs.getInt("numero_mesa"));
                row.put("capacidad", cap);
                row.put("nombreZona", rs.getString("nombre_zona"));
                row.put("puestoVotacion", rs.getString("puesto_votacion"));
                row.put("idZona", rs.getInt("id_zona"));
                row.put("ciudad", rs.getString("ciudad"));
                row.put("ciudadanosInscritos", ins);
                row.put("porcentajeOcupacion", pct);
                lista.add(row);
            }
        }
        return lista;
    }

    private List<Map<String, Object>> listarZonas() throws Exception {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT z.id, z.nombre_zona, z.puesto_votacion, ci.nombre AS ciudad "
                + "FROM zonas_votacion z "
                + "INNER JOIN ciudades ci ON z.id_ciudad = ci.id "
                + "ORDER BY ci.nombre, z.nombre_zona";
        try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("id", rs.getInt("id"));
                row.put("nombreZona", rs.getString("nombre_zona"));
                row.put("puestoVotacion", rs.getString("puesto_votacion"));
                row.put("ciudad", rs.getString("ciudad"));
                lista.add(row);
            }
        }
        return lista;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("eliminar".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                // Desasignar ciudadanos primero
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(
                        "UPDATE ciudadanos SET id_mesa = NULL WHERE id_mesa = ?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM mesas_votacion WHERE id = ?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                resp.sendRedirect(req.getContextPath() + "/admin/mesas?ok=eliminado");

            } else {
                List<Map<String, Object>> mesas = listarMesas();
                // Calcular capacidad total e inscritos totales
                int capTotal = 0, inscTotal = 0;
                for (Map<String, Object> m : mesas) {
                    capTotal += (int) m.get("capacidad");
                    inscTotal += (int) m.get("ciudadanosInscritos");
                }
                req.setAttribute("mesas", mesas);
                req.setAttribute("zonas", listarZonas());
                req.setAttribute("capacidadTotal", capTotal);
                req.setAttribute("ciudadanosInscritos", inscTotal);
                if ("guardado".equals(req.getParameter("ok"))) {
                    req.setAttribute("successMsg", "Mesa guardada correctamente.");
                }
                if ("eliminado".equals(req.getParameter("ok"))) {
                    req.setAttribute("successMsg", "Mesa eliminada correctamente.");
                }
                req.getRequestDispatcher("/WEB-INF/vistas/admin/mesas/listado.jsp")
                        .forward(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException("Error en MesaServlet: " + e.getMessage(), e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");

        // Manejar eliminación por POST (mejor práctica)
        if ("eliminar".equals(action)) {
            try {
                int id = Integer.parseInt(req.getParameter("id"));
                // Desasignar ciudadanos primero
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(
                        "UPDATE ciudadanos SET id_mesa = NULL WHERE id_mesa = ?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM mesas_votacion WHERE id = ?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
                resp.sendRedirect(req.getContextPath() + "/admin/mesas?ok=eliminado");
                return;
            } catch (Exception e) {
                throw new ServletException("Error eliminando mesa: " + e.getMessage(), e);
            }
        }

        try {
            String idParam = req.getParameter("id");
            int idZona = Integer.parseInt(req.getParameter("idZona"));
            int numeroMesa = Integer.parseInt(req.getParameter("numeroMesa"));
            int capacidad = Integer.parseInt(req.getParameter("capacidad"));

            if (idParam == null || idParam.isEmpty()) {
                String sql = "INSERT INTO mesas_votacion (id_zona, numero_mesa, capacidad) VALUES (?, ?, ?)";
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, idZona);
                    ps.setInt(2, numeroMesa);
                    ps.setInt(3, capacidad);
                    ps.executeUpdate();
                }
            } else {
                String sql = "UPDATE mesas_votacion SET id_zona=?, numero_mesa=?, capacidad=? WHERE id=?";
                try (Connection con = ConexionDB.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, idZona);
                    ps.setInt(2, numeroMesa);
                    ps.setInt(3, capacidad);
                    ps.setInt(4, Integer.parseInt(idParam));
                    ps.executeUpdate();
                }
            }
            resp.sendRedirect(req.getContextPath() + "/admin/mesas?ok=guardado");
        } catch (Exception e) {
            throw new ServletException("Error guardando mesa: " + e.getMessage(), e);
        }
    }
}
