<%@ page contentType="text/html;charset=UTF-8" %>
<%-- Página de inicio: redirige a la landing page institucional --%>
<jsp:forward page="/home.jsp"/>
