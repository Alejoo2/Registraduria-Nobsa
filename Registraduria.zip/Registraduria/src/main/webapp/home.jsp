<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registraduría Municipal de Nobsa — Boyacá</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,300;8..60,400;8..60,600;8..60,700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <style>
            :root {
                --azul-oscuro:  #003366;
                --azul-medio:   #1A5EA8;
                --azul-vivo:    #2563EB;
                --azul-claro:   #EBF2FC;
                --dorado:       #C8972B;
                --blanco:       #FFFFFF;
                --gris-50:      #F8FAFC;
                --gris-100:     #F1F5F9;
                --gris-200:     #E2E8F0;
                --gris-400:     #94A3B8;
                --gris-600:     #475569;
                --gris-700:     #334155;
                --negro:        #0F172A;
                --font-serif:   'Source Serif 4', Georgia, serif;
                --font-body:    'IBM Plex Sans', system-ui, sans-serif;
            }
            *, *::before, *::after {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            html {
                scroll-behavior: smooth;
            }
            body {
                font-family: var(--font-body);
                background: var(--gris-50);
                color: var(--negro);
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }

            /* ── GOV BAR ── */
            .gov-bar {
                background: var(--azul-oscuro);
                color: rgba(255,255,255,.70);
                font-size: 11.5px;
                padding: 7px 0;
                text-align: center;
                letter-spacing: .4px;
            }
            .gov-bar span {
                color: rgba(255,255,255,.35);
                margin: 0 10px;
            }

            /* ── HEADER ── */
            .site-header {
                background: var(--blanco);
                border-bottom: 3px solid var(--azul-oscuro);
                padding: 0;
            }
            .header-inner {
                max-width: 1100px;
                margin: 0 auto;
                padding: 18px 32px;
                display: flex;
                align-items: center;
                gap: 20px;
            }
            .header-logo {
                width: 58px;
                height: 58px;
                background: var(--azul-oscuro);
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                box-shadow: 0 4px 14px rgba(0,51,102,.25);
            }
            .header-logo i {
                color: var(--blanco);
                font-size: 24px;
            }
            .header-brand h1 {
                font-family: var(--font-serif);
                font-size: 22px;
                font-weight: 700;
                color: var(--azul-oscuro);
                line-height: 1.2;
            }
            .header-brand p {
                font-size: 13px;
                color: var(--gris-600);
                margin-top: 3px;
            }
            .header-actions {
                margin-left: auto;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .btn-admin-access {
                display: flex;
                align-items: center;
                gap: 7px;
                padding: 9px 18px;
                background: transparent;
                border: 1.5px solid var(--azul-oscuro);
                color: var(--azul-oscuro);
                border-radius: 6px;
                font-family: var(--font-body);
                font-size: 13.5px;
                font-weight: 600;
                text-decoration: none;
                transition: all .15s;
            }
            .btn-admin-access:hover {
                background: var(--azul-oscuro);
                color: var(--blanco);
            }

            /* ── HERO ── */
            .hero {
                background: linear-gradient(160deg, var(--azul-oscuro) 0%, #0a4a8a 60%, var(--azul-medio) 100%);
                padding: 80px 32px 90px;
                text-align: center;
                position: relative;
                overflow: hidden;
            }
            .hero::before {
                content: '';
                position: absolute;
                inset: 0;
                background:
                    radial-gradient(ellipse 60% 80% at 20% 50%, rgba(37,99,235,.18) 0%, transparent 60%),
                    radial-gradient(ellipse 50% 60% at 80% 30%, rgba(200,151,43,.10) 0%, transparent 60%);
                pointer-events: none;
            }
            .hero-inner {
                max-width: 720px;
                margin: 0 auto;
                position: relative;
            }
            .hero-escudo {
                width: 80px;
                height: 80px;
                background: rgba(255,255,255,.12);
                border: 2px solid rgba(255,255,255,.25);
                border-radius: 50%;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 24px;
            }
            .hero-escudo i {
                color: var(--blanco);
                font-size: 34px;
            }
            .hero h2 {
                font-family: var(--font-serif);
                font-size: 40px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1.2;
                margin-bottom: 16px;
            }
            .hero p {
                font-size: 17px;
                color: rgba(255,255,255,.82);
                line-height: 1.7;
                margin-bottom: 40px;
                max-width: 560px;
                margin-left: auto;
                margin-right: auto;
            }
            .hero-cta {
                display: inline-flex;
                align-items: center;
                gap: 10px;
                background: var(--blanco);
                color: var(--azul-oscuro);
                padding: 16px 32px;
                border-radius: 8px;
                font-family: var(--font-body);
                font-size: 16px;
                font-weight: 700;
                text-decoration: none;
                box-shadow: 0 6px 24px rgba(0,0,0,.25);
                transition: all .2s;
                letter-spacing: .2px;
            }
            .hero-cta:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 32px rgba(0,0,0,.3);
                background: var(--azul-claro);
            }
            .hero-cta i {
                font-size: 18px;
                color: var(--azul-vivo);
            }
            .hero-note {
                margin-top: 18px;
                font-size: 13px;
                color: rgba(255,255,255,.55);
            }
            .hero-note i {
                margin-right: 4px;
            }

            /* ── SERVICIOS ── */
            .section {
                max-width: 1100px;
                margin: 0 auto;
                padding: 72px 32px;
            }
            .section-label {
                font-size: 11px;
                font-weight: 700;
                letter-spacing: 2px;
                text-transform: uppercase;
                color: var(--azul-medio);
                margin-bottom: 10px;
            }
            .section-title {
                font-family: var(--font-serif);
                font-size: 30px;
                font-weight: 700;
                color: var(--negro);
                margin-bottom: 14px;
            }
            .section-desc {
                font-size: 15.5px;
                color: var(--gris-600);
                line-height: 1.7;
                max-width: 560px;
                margin-bottom: 48px;
            }

            .services-grid {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 20px;
            }
            .service-card {
                background: var(--blanco);
                border: 1px solid var(--gris-200);
                border-radius: 12px;
                padding: 28px 26px;
                box-shadow: 0 2px 8px rgba(0,0,0,.06);
                transition: box-shadow .2s, transform .2s;
            }
            .service-card:hover {
                box-shadow: 0 8px 28px rgba(0,51,102,.12);
                transform: translateY(-3px);
            }
            .service-icon {
                width: 52px;
                height: 52px;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 18px;
            }
            .service-icon.azul  {
                background: var(--azul-claro);
            }
            .service-icon.azul i {
                color: var(--azul-oscuro);
                font-size: 22px;
            }
            .service-icon.verde {
                background: #E0F2F1;
            }
            .service-icon.verde i {
                color: #0F7E6A;
                font-size: 22px;
            }
            .service-icon.dorado {
                background: #FDF6E3;
            }
            .service-icon.dorado i {
                color: var(--dorado);
                font-size: 22px;
            }
            .service-card h3 {
                font-size: 16px;
                font-weight: 700;
                color: var(--negro);
                margin-bottom: 8px;
            }
            .service-card p {
                font-size: 13.5px;
                color: var(--gris-600);
                line-height: 1.65;
            }

            /* ── NÚMEROS / STATS ── */
            .stats-section {
                background: var(--azul-oscuro);
                padding: 60px 32px;
            }
            .stats-inner {
                max-width: 900px;
                margin: 0 auto;
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 24px;
                text-align: center;
            }
            .stat-item {
            }
            .stat-num {
                font-family: var(--font-serif);
                font-size: 40px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1;
                margin-bottom: 8px;
            }
            .stat-desc {
                font-size: 13px;
                color: rgba(255,255,255,.65);
                line-height: 1.5;
            }

            /* ── CONSULTA CTA ── */
            .cta-section {
                background: var(--gris-100);
                border-top: 1px solid var(--gris-200);
                border-bottom: 1px solid var(--gris-200);
                padding: 64px 32px;
                text-align: center;
            }
            .cta-inner {
                max-width: 600px;
                margin: 0 auto;
            }
            .cta-inner .badge-chip {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                background: var(--azul-claro);
                color: var(--azul-medio);
                padding: 5px 14px;
                border-radius: 20px;
                font-size: 12.5px;
                font-weight: 600;
                margin-bottom: 20px;
            }
            .cta-inner h2 {
                font-family: var(--font-serif);
                font-size: 32px;
                font-weight: 700;
                color: var(--negro);
                margin-bottom: 14px;
                line-height: 1.25;
            }
            .cta-inner p {
                font-size: 15px;
                color: var(--gris-600);
                line-height: 1.7;
                margin-bottom: 32px;
            }
            .cta-btn {
                display: inline-flex;
                align-items: center;
                gap: 10px;
                background: var(--azul-oscuro);
                color: var(--blanco);
                padding: 15px 30px;
                border-radius: 8px;
                font-family: var(--font-body);
                font-size: 15px;
                font-weight: 600;
                text-decoration: none;
                box-shadow: 0 4px 16px rgba(0,51,102,.25);
                transition: all .15s;
            }
            .cta-btn:hover {
                background: var(--azul-medio);
                transform: translateY(-1px);
            }

            /* ── FOOTER ── */
            .site-footer {
                background: var(--negro);
                padding: 40px 32px 28px;
                margin-top: auto;
            }
            .footer-inner {
                max-width: 1100px;
                margin: 0 auto;
            }
            .footer-grid {
                display: grid;
                grid-template-columns: 2fr 1fr 1fr;
                gap: 40px;
                margin-bottom: 36px;
            }
            .footer-brand .logo-row {
                display: flex;
                align-items: center;
                gap: 12px;
                margin-bottom: 14px;
            }
            .footer-brand .f-icon {
                width: 38px;
                height: 38px;
                background: rgba(255,255,255,.1);
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .footer-brand .f-icon i {
                color: var(--blanco);
                font-size: 16px;
            }
            .footer-brand h3 {
                font-family: var(--font-serif);
                font-size: 15px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1.3;
            }
            .footer-brand p {
                font-size: 13px;
                color: rgba(255,255,255,.5);
                line-height: 1.65;
            }
            .footer-col h4 {
                font-size: 12px;
                font-weight: 700;
                letter-spacing: 1.2px;
                text-transform: uppercase;
                color: rgba(255,255,255,.4);
                margin-bottom: 14px;
            }
            .footer-col ul {
                list-style: none;
            }
            .footer-col li {
                margin-bottom: 9px;
            }
            .footer-col a {
                font-size: 13.5px;
                color: rgba(255,255,255,.65);
                text-decoration: none;
                transition: color .15s;
            }
            .footer-col a:hover {
                color: var(--blanco);
            }
            .footer-divider {
                border: none;
                border-top: 1px solid rgba(255,255,255,.08);
                margin-bottom: 20px;
            }
            .footer-bottom {
                display: flex;
                align-items: center;
                justify-content: space-between;
                font-size: 12px;
                color: rgba(255,255,255,.35);
            }
            .footer-bottom a {
                color: rgba(255,255,255,.35);
                text-decoration: none;
            }
            .footer-bottom a:hover {
                color: rgba(255,255,255,.6);
            }

            /* ── RESPONSIVE ── */
            @media (max-width: 900px) {
                .services-grid {
                    grid-template-columns: repeat(2, 1fr);
                }
                .stats-inner {
                    grid-template-columns: repeat(2, 1fr);
                }
                .footer-grid {
                    grid-template-columns: 1fr;
                    gap: 28px;
                }
            }
            @media (max-width: 600px) {
                .hero h2 {
                    font-size: 28px;
                }
                .services-grid {
                    grid-template-columns: 1fr;
                }
                .header-brand h1 {
                    font-size: 17px;
                }
                .btn-admin-access .label {
                    display: none;
                }
                .stats-inner {
                    grid-template-columns: repeat(2, 1fr);
                }
            }
        </style>
    </head>
    <body>

        <!-- Barra institucional -->
        <div class="gov-bar">
            República de Colombia
            <span>·</span>
            Registraduría Nacional del Estado Civil
            <span>·</span>
            Delegación Municipal de Nobsa, Boyacá
        </div>

        <!-- Header principal -->
        <header class="site-header">
            <div class="header-inner">
                <div class="header-logo"><i class="fas fa-landmark"></i></div>
                <div class="header-brand">
                    <h1>Registraduría Municipal de Nobsa</h1>
                    <p>Boyacá, Colombia &mdash; Servicios de Registro Civil y Electoral</p>
                </div>
                <div class="header-actions">
                    <a href="${pageContext.request.contextPath}/admin/login" class="btn-admin-access">
                        <i class="fas fa-lock"></i>
                        <span class="label">Panel Administrativo</span>
                    </a>
                </div>
            </div>
        </header>

        <!-- Hero -->
        <section class="hero">
            <div class="hero-inner">
                <div class="hero-escudo"><i class="fas fa-vote-yea"></i></div>
                <h2>Consulte su Puesto<br>de Votación en Línea</h2>
                <p>
                    Servicio gratuito para ciudadanos de Nobsa y municipios vecinos del departamento de Boyacá.
                    Conozca en segundos dónde le corresponde ejercer su derecho al voto.
                </p>
                <a href="${pageContext.request.contextPath}/consulta-mesa" class="hero-cta">
                    <i class="fas fa-search"></i>
                    Consultar mi puesto de votación
                </a>
                <p class="hero-note">
                    <i class="fas fa-lock"></i>
                    Solo ingrese su número de cédula — sin registro previo
                </p>
            </div>
        </section>

        <!-- Servicios -->
        <section class="section">
            <p class="section-label">Nuestros servicios</p>
            <h2 class="section-title">¿Qué puede hacer aquí?</h2>
            <p class="section-desc">
                La Registraduría Municipal de Nobsa ofrece servicios de identificación y organización
                electoral para todos los ciudadanos del municipio.
            </p>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon azul"><i class="fas fa-search-location"></i></div>
                    <h3>Consulta de Puesto de Votación</h3>
                    <p>
                        Conozca en qué zona, puesto y número de mesa debe votar, ingresando únicamente
                        su número de documento de identidad.
                    </p>
                </div>
                <div class="service-card">
                    <div class="service-icon verde"><i class="fas fa-id-card"></i></div>
                    <h3>Gestión de Documentos</h3>
                    <p>
                        Administración de cédulas de ciudadanía, tarjetas de identidad, registros civiles
                        de nacimiento y contraseñas de identificación.
                    </p>
                </div>
                <div class="service-card">
                    <div class="service-icon dorado"><i class="fas fa-map-marked-alt"></i></div>
                    <h3>Información Electoral</h3>
                    <p>
                        Consulte las zonas de votación, puestos electorales y mesas habilitadas para
                        las elecciones en el municipio de Nobsa.
                    </p>
                </div>
            </div>
        </section>

        <!-- Stats -->
        <section class="stats-section">
            <div class="stats-inner">
                <div class="stat-item">
                    <div class="stat-num">3</div>
                    <div class="stat-desc">Zonas de<br>votación activas</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">8</div>
                    <div class="stat-desc">Mesas de<br>votación habilitadas</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">1.500+</div>
                    <div class="stat-desc">Votantes<br>capacidad total</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">Nobsa</div>
                    <div class="stat-desc">Municipio de<br>Boyacá, Colombia</div>
                </div>
            </div>
        </section>

        <!-- CTA consulta -->
        <section class="cta-section">
            <div class="cta-inner">
                <div class="badge-chip">
                    <i class="fas fa-bolt"></i> Consulta rápida
                </div>
                <h2>¿Dónde le corresponde votar?</h2>
                <p>
                    Ingrese su cédula y en menos de 3 segundos conocerá su zona de votación,
                    puesto y número de mesa. Es gratuito, no requiere registro y funciona en cualquier dispositivo.
                </p>
                <a href="${pageContext.request.contextPath}/consulta-mesa" class="cta-btn">
                    <i class="fas fa-fingerprint"></i>
                    Consultar ahora
                </a>
            </div>
        </section>

        <!-- Footer -->
        <footer class="site-footer">
            <div class="footer-inner">
                <div class="footer-grid">
                    <div class="footer-brand">
                        <div class="logo-row">
                            <div class="f-icon"><i class="fas fa-landmark"></i></div>
                            <h3>Registraduría Municipal<br>de Nobsa</h3>
                        </div>
                        <p>
                            Entidad del Estado colombiano encargada de organizar los procesos electorales
                            y expedir documentos de identidad en el municipio de Nobsa, Boyacá.
                            Calle 5 # 4-32, Centro — Nobsa, Boyacá.
                        </p>
                    </div>
                    <div class="footer-col">
                        <h4>Servicios</h4>
                        <ul>
                            <li><a href="${pageContext.request.contextPath}/consulta-mesa">Consulta electoral</a></li>
                            <li><a href="#">Cédula de ciudadanía</a></li>
                            <li><a href="#">Registro civil</a></li>
                            <li><a href="#">Tarjeta de identidad</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>Acceso interno</h4>
                        <ul>
                            <li><a href="${pageContext.request.contextPath}/admin/login">Panel administrativo</a></li>
                            <li><a href="${pageContext.request.contextPath}/admin/dashboard">Dashboard</a></li>
                        </ul>
                    </div>
                </div>
                <hr class="footer-divider">
                <div class="footer-bottom">
                    <span>&copy; 2026 Registraduría Municipal de Nobsa — Todos los derechos reservados</span>
                    <span>SENA · ADSO · CIMM · Regional Boyacá</span>
                </div>
            </div>
        </footer>

    </body>
</html>
