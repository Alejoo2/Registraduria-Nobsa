<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Resultado Consulta — Registraduría de Nobsa</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <style>
            :root {
                --azul-oscuro:  #003366;
                --azul-medio:   #1A5EA8;
                --azul-vivo:    #2563EB;
                --azul-claro:   #EBF2FC;
                --blanco:       #FFFFFF;
                --gris-50:      #F8FAFC;
                --gris-100:     #F1F5F9;
                --gris-200:     #E2E8F0;
                --gris-300:     #CBD5E1;
                --gris-400:     #94A3B8;
                --gris-600:     #475569;
                --gris-700:     #334155;
                --negro:        #0F172A;
                --verde:        #15803D;
                --verde-claro:  #F0FDF4;
                --rojo:         #DC2626;
                --rojo-claro:   #FEF2F2;
                --amarillo:     #B45309;
                --amarillo-claro: #FFFBEB;
                --font-serif:   'Source Serif 4', Georgia, serif;
                --font-body:    'IBM Plex Sans', system-ui, sans-serif;
            }
            *, *::before, *::after {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            body {
                font-family: var(--font-body);
                background: var(--gris-50);
                color: var(--negro);
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }

            /* ═══ BARRA INSTITUCIONAL ═══ */
            .gov-bar {
                background: var(--azul-oscuro);
                color: rgba(255,255,255,.75);
                font-size: 12px;
                padding: 6px 0;
                text-align: center;
                letter-spacing: .3px;
            }
            .gov-bar span {
                color: rgba(255,255,255,.5);
                margin: 0 8px;
            }

            /* ═══ HEADER ═══ */
            .site-header {
                background: var(--blanco);
                border-bottom: 3px solid var(--azul-oscuro);
                padding: 16px 0;
            }
            .header-inner {
                max-width: 800px;
                margin: 0 auto;
                padding: 0 24px;
                display: flex;
                align-items: center;
                gap: 16px;
            }
            .header-escudo {
                width: 40px;
                height: 40px;
                background: var(--azul-oscuro);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .header-escudo i {
                color: var(--blanco);
                font-size: 17px;
            }
            .header-text h1 {
                font-family: var(--font-serif);
                font-size: 16px;
                font-weight: 700;
                color: var(--azul-oscuro);
                line-height: 1.3;
            }
            .header-text p {
                font-size: 12px;
                color: var(--gris-600);
            }

            /* ═══ ÁREA PRINCIPAL ═══ */
            .main {
                flex: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 40px 24px;
            }
            .result-card {
                background: var(--blanco);
                border-radius: 12px;
                box-shadow: 0 4px 24px rgba(0,0,0,.08);
                width: 100%;
                max-width: 580px;
                overflow: hidden;
                animation: fadeIn .35s ease both;
            }

            /* ═══ CASO 1: CON MESA ASIGNADA ═══ */
            .result-header-ok {
                background: linear-gradient(135deg, var(--azul-oscuro) 0%, var(--azul-medio) 100%);
                padding: 28px 36px 24px;
                display: flex;
                align-items: center;
                gap: 16px;
            }
            .result-header-ok .check-icon {
                width: 52px;
                height: 52px;
                background: rgba(255,255,255,.2);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .result-header-ok .check-icon i {
                color: var(--blanco);
                font-size: 22px;
            }
            .result-header-ok .hdr-text h2 {
                font-family: var(--font-serif);
                font-size: 20px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1.3;
            }
            .result-header-ok .hdr-text p {
                font-size: 13.5px;
                color: rgba(255,255,255,.75);
                margin-top: 3px;
            }

            .citizen-name {
                padding: 20px 36px 0;
                font-family: var(--font-serif);
                font-size: 15px;
                color: var(--gris-600);
            }
            .citizen-name strong {
                font-size: 20px;
                font-weight: 700;
                color: var(--negro);
                display: block;
                margin-top: 2px;
            }
            .citizen-doc {
                font-size: 12.5px;
                color: var(--gris-400);
                font-family: monospace;
                margin-top: 2px;
            }

            /* Grilla de datos de votación */
            .vote-grid {
                padding: 24px 36px 32px;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 16px;
            }
            .vote-cell {
                background: var(--gris-50);
                border: 1px solid var(--gris-200);
                border-radius: 8px;
                padding: 16px 18px;
            }
            .vote-cell.highlight {
                background: var(--azul-claro);
                border-color: #BFDBFE;
            }
            .vote-cell.highlight.mesa-num {
                grid-column: span 2;
                background: var(--azul-oscuro);
                border-color: var(--azul-oscuro);
                text-align: center;
                padding: 20px;
            }
            .vote-cell .vc-label {
                font-size: 11px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 1px;
                color: var(--gris-400);
                margin-bottom: 6px;
                display: flex;
                align-items: center;
                gap: 5px;
            }
            .vote-cell.highlight .vc-label  {
                color: var(--azul-medio);
            }
            .vote-cell.mesa-num  .vc-label  {
                color: rgba(255,255,255,.6);
                justify-content: center;
            }
            .vote-cell .vc-value {
                font-size: 16px;
                font-weight: 600;
                color: var(--negro);
                line-height: 1.3;
            }
            .vote-cell.highlight .vc-value  {
                color: var(--azul-oscuro);
            }
            .vote-cell.mesa-num  .vc-value  {
                font-family: var(--font-serif);
                font-size: 48px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1;
                margin-top: 2px;
            }
            .vote-cell .vc-sub {
                font-size: 12px;
                color: var(--gris-400);
                margin-top: 2px;
            }
            .vote-cell.mesa-num .vc-sub {
                color: rgba(255,255,255,.6);
                font-size: 13px;
            }

            /* Acciones */
            .result-actions {
                padding: 0 36px 32px;
                display: flex;
                gap: 12px;
                flex-wrap: wrap;
            }
            .btn {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                padding: 11px 20px;
                border-radius: 6px;
                font-family: var(--font-body);
                font-size: 14px;
                font-weight: 500;
                cursor: pointer;
                border: none;
                text-decoration: none;
                transition: all .15s;
            }
            .btn-primary {
                background: var(--azul-oscuro);
                color: var(--blanco);
            }
            .btn-primary:hover {
                background: var(--azul-medio);
            }
            .btn-secondary {
                background: var(--blanco);
                color: var(--gris-700);
                border: 1.5px solid var(--gris-300);
            }
            .btn-secondary:hover {
                background: var(--gris-100);
            }

            /* ═══ CASO 2: SIN MESA ASIGNADA ═══ */
            .result-header-warn {
                background: linear-gradient(135deg, #92400E 0%, #B45309 100%);
                padding: 28px 36px 24px;
                display: flex;
                align-items: center;
                gap: 16px;
            }
            .result-header-warn .warn-icon {
                width: 52px;
                height: 52px;
                background: rgba(255,255,255,.2);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .result-header-warn .warn-icon i {
                color: var(--blanco);
                font-size: 22px;
            }
            .result-header-warn .hdr-text h2 {
                font-family: var(--font-serif);
                font-size: 20px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1.3;
            }
            .result-header-warn .hdr-text p {
                font-size: 13.5px;
                color: rgba(255,255,255,.75);
                margin-top: 3px;
            }

            .warn-body {
                padding: 28px 36px 32px;
            }
            .warn-msg {
                background: var(--amarillo-claro);
                border: 1px solid #FDE68A;
                border-left: 4px solid var(--amarillo);
                border-radius: 6px;
                padding: 16px 18px;
                font-size: 14px;
                color: #78350F;
                line-height: 1.6;
                margin-bottom: 24px;
            }
            .citizen-info-row {
                display: flex;
                align-items: center;
                gap: 12px;
                margin-bottom: 20px;
            }
            .ci-avatar {
                width: 44px;
                height: 44px;
                background: var(--gris-100);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .ci-avatar i {
                color: var(--gris-400);
                font-size: 18px;
            }
            .ci-name {
                font-size: 17px;
                font-weight: 600;
                color: var(--negro);
            }
            .ci-doc  {
                font-size: 12.5px;
                color: var(--gris-400);
                font-family: monospace;
            }

            /* ═══ CASO 3: NO ENCONTRADO ═══ */
            .result-header-err {
                background: linear-gradient(135deg, #7F1D1D 0%, var(--rojo) 100%);
                padding: 28px 36px 24px;
                display: flex;
                align-items: center;
                gap: 16px;
            }
            .result-header-err .err-icon {
                width: 52px;
                height: 52px;
                background: rgba(255,255,255,.2);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .result-header-err .err-icon i {
                color: var(--blanco);
                font-size: 22px;
            }
            .result-header-err .hdr-text h2 {
                font-family: var(--font-serif);
                font-size: 20px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1.3;
            }
            .result-header-err .hdr-text p {
                font-size: 13.5px;
                color: rgba(255,255,255,.75);
                margin-top: 3px;
            }

            .err-body {
                padding: 28px 36px 32px;
            }
            .err-cedula {
                font-family: monospace;
                font-size: 28px;
                font-weight: 700;
                color: var(--negro);
                display: block;
                margin-bottom: 12px;
                letter-spacing: 2px;
            }
            .err-msg {
                background: var(--rojo-claro);
                border: 1px solid #FECACA;
                border-left: 4px solid var(--rojo);
                border-radius: 6px;
                padding: 16px 18px;
                font-size: 14px;
                color: #7F1D1D;
                line-height: 1.6;
                margin-bottom: 24px;
            }

            /* ═══ FOOTER ═══ */
            .site-footer {
                background: var(--blanco);
                border-top: 1px solid var(--gris-200);
                padding: 14px 0;
                text-align: center;
                font-size: 12px;
                color: var(--gris-400);
            }

            /* Animación fade-in */
            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(12px);
                }
                to   {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            @media print {
                .gov-bar, .site-header, .result-actions, .site-footer {
                    display: none;
                }
                body {
                    background: white;
                }
                .result-card {
                    box-shadow: none;
                    border: 1px solid #ccc;
                }
                .main {
                    padding: 0;
                }
            }

            @media (max-width: 540px) {
                .vote-grid {
                    grid-template-columns: 1fr;
                    padding: 20px 24px 28px;
                }
                .vote-cell.mesa-num {
                    grid-column: span 1;
                }
                .result-header-ok,
                .result-header-warn,
                .result-header-err {
                    padding: 22px 24px 20px;
                }
                .citizen-name,
                .result-actions,
                .warn-body, .err-body {
                    padding-left: 24px;
                    padding-right: 24px;
                }
            }
        </style>
    </head>
    <body>

        <div class="gov-bar">
            República de Colombia
            <span>·</span>
            Registraduría Nacional del Estado Civil
            <span>·</span>
            Municipal de Nobsa, Boyacá
        </div>

        <header class="site-header">
            <div class="header-inner">
                <div class="header-escudo"><i class="fas fa-landmark"></i></div>
                <div class="header-text">
                    <h1>Registraduría Municipal de Nobsa</h1>
                    <p>Boyacá, Colombia</p>
                </div>
            </div>
        </header>

        <main class="main">

            <%-- ══════════════════════════════════════
                 CASO 1 — Ciudadano con mesa asignada
                 ══════════════════════════════════════ --%>
            <c:if test="${not empty resultado}">
                <div class="result-card">

                    <div class="result-header-ok">
                        <div class="check-icon"><i class="fas fa-check"></i></div>
                        <div class="hdr-text">
                            <h2>Puesto de Votación Encontrado</h2>
                            <p>Información electoral actualizada para las próximas elecciones</p>
                        </div>
                    </div>

                    <div class="citizen-name">
                        Ciudadano registrado:
                        <strong>${resultado.nombres} ${resultado.apellidos}</strong>
                        <div class="citizen-doc">Documento: ${resultado.numeroDocumento}</div>
                    </div>

                    <div class="vote-grid">
                        <div class="vote-cell highlight">
                            <div class="vc-label"><i class="fas fa-city"></i> Municipio</div>
                            <div class="vc-value">${resultado.ciudad}</div>
                            <div class="vc-sub">Código DANE: ${resultado.codigoDane}</div>
                        </div>
                        <div class="vote-cell highlight">
                            <div class="vc-label"><i class="fas fa-map-marked-alt"></i> Zona de Votación</div>
                            <div class="vc-value">${resultado.nombreZona}</div>
                        </div>
                        <div class="vote-cell" style="grid-column:span 2;">
                            <div class="vc-label"><i class="fas fa-school"></i> Puesto de Votación</div>
                            <div class="vc-value">${resultado.puestoVotacion}</div>
                            <div class="vc-sub"><i class="fas fa-map-pin" style="margin-right:4px;color:var(--gris-400)"></i>${resultado.direccion}</div>
                        </div>
                        <div class="vote-cell highlight mesa-num">
                            <div class="vc-label"><i class="fas fa-table"></i> Mesa de Votación</div>
                            <div class="vc-value">${resultado.numeroMesa}</div>
                            <div class="vc-sub">Capacidad máxima: ${resultado.capacidad} votantes</div>
                        </div>
                    </div>

                    <div class="result-actions">
                        <button onclick="window.print()" class="btn btn-primary">
                            <i class="fas fa-print"></i> Imprimir comprobante
                        </button>
                        <a href="${pageContext.request.contextPath}/consulta-mesa" class="btn btn-secondary">
                            <i class="fas fa-search"></i> Nueva consulta
                        </a>
                    </div>

                </div>
            </c:if>

            <%-- ══════════════════════════════════════
                 CASO 2 — Ciudadano sin mesa asignada
                 ══════════════════════════════════════ --%>
            <c:if test="${not empty ciudadanoSinMesa}">
                <div class="result-card">

                    <div class="result-header-warn">
                        <div class="warn-icon"><i class="fas fa-exclamation-triangle"></i></div>
                        <div class="hdr-text">
                            <h2>Sin Mesa de Votación Asignada</h2>
                            <p>El ciudadano está registrado pero aún no tiene mesa asignada</p>
                        </div>
                    </div>

                    <div class="warn-body">
                        <div class="citizen-info-row">
                            <div class="ci-avatar"><i class="fas fa-user"></i></div>
                            <div>
                                <div class="ci-name">${ciudadanoSinMesa.nombres} ${ciudadanoSinMesa.apellidos}</div>
                                <div class="ci-doc">Documento: ${ciudadanoSinMesa.numeroDocumento}</div>
                            </div>
                        </div>
                        <div class="warn-msg">
                            <strong><i class="fas fa-info-circle"></i> Su inscripción está pendiente de asignación.</strong><br>
                            El ciudadano fue encontrado en el sistema, pero aún no tiene una mesa de votación asignada.
                            Por favor diríjase personalmente a la Registraduría Municipal de Nobsa para regularizar su inscripción electoral antes de la fecha límite.
                        </div>
                        <div class="result-actions" style="padding:0;">
                            <a href="${pageContext.request.contextPath}/consulta-mesa" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Volver
                            </a>
                        </div>
                    </div>

                </div>
            </c:if>

            <%-- ══════════════════════════════════════
                 CASO 3 — Cédula no encontrada
                 ══════════════════════════════════════ --%>
            <c:if test="${noEncontrado == true}">
                <div class="result-card">

                    <div class="result-header-err">
                        <div class="err-icon"><i class="fas fa-times-circle"></i></div>
                        <div class="hdr-text">
                            <h2>Documento No Encontrado</h2>
                            <p>La cédula consultada no está registrada en el sistema</p>
                        </div>
                    </div>

                    <div class="err-body">
                        <span class="err-cedula">${documentoBuscado}</span>
                        <div class="err-msg">
                            <strong><i class="fas fa-exclamation-circle"></i> No se encontró ningún registro con este número de documento.</strong><br>
                            Verifique que ingresó correctamente el número de cédula sin puntos ni espacios.
                            Si el error persiste, diríjase a la Registraduría Municipal de Nobsa ubicada en la Calle 5 # 4-32, Centro.
                        </div>
                        <div class="result-actions" style="padding:0;">
                            <a href="${pageContext.request.contextPath}/consulta-mesa" class="btn btn-primary">
                                <i class="fas fa-search"></i> Intentar de nuevo
                            </a>
                        </div>
                    </div>

                </div>
            </c:if>

        </main>

        <footer class="site-footer">
            Registraduría Municipal de Nobsa &mdash; Boyacá, Colombia
            &nbsp;&bull;&nbsp;
            Sistema de Información Electoral
            &nbsp;&bull;&nbsp;
            SENA · ADSO · CIMM 2026
        </footer>

    </body>
</html>
