<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Consulta de Puesto de Votación — Registraduría de Nobsa</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <style>
            :root {
                --azul-oscuro:  #003366;
                --azul-medio:   #1A5EA8;
                --azul-vivo:    #2563EB;
                --azul-claro:   #EBF2FC;
                --blanco:       #FFFFFF;
                --gris-50:      #F8FAFC;
                --gris-100:     #F1F5F9;
                --gris-200:     #E2E8F0;
                --gris-300:     #CBD5E1;
                --gris-400:     #94A3B8;
                --gris-600:     #475569;
                --gris-700:     #334155;
                --negro:        #0F172A;
                --rojo:         #DC2626;
                --rojo-claro:   #FEF2F2;
                --font-serif:   'Source Serif 4', Georgia, serif;
                --font-body:    'IBM Plex Sans', system-ui, sans-serif;
            }
            *, *::before, *::after {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }

            html {
                font-size: 16px;
            }

            body {
                font-family: var(--font-body);
                background: var(--gris-50);
                color: var(--negro);
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }

            /* ═══ BARRA INSTITUCIONAL SUPERIOR ═══ */
            .gov-bar {
                background: var(--azul-oscuro);
                color: rgba(255,255,255,.75);
                font-size: 12px;
                padding: 6px 0;
                text-align: center;
                letter-spacing: .3px;
            }
            .gov-bar span {
                color: rgba(255,255,255,.5);
                margin: 0 8px;
            }

            /* ═══ HEADER ══ */
            .site-header {
                background: var(--blanco);
                border-bottom: 3px solid var(--azul-oscuro);
                padding: 20px 0;
            }
            .header-inner {
                max-width: 800px;
                margin: 0 auto;
                padding: 0 24px;
                display: flex;
                align-items: center;
                gap: 18px;
            }
            .header-escudo {
                width: 52px;
                height: 52px;
                background: var(--azul-oscuro);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .header-escudo i {
                color: var(--blanco);
                font-size: 22px;
            }
            .header-text h1 {
                font-family: var(--font-serif);
                font-size: 20px;
                font-weight: 700;
                color: var(--azul-oscuro);
                line-height: 1.3;
            }
            .header-text p {
                font-size: 13px;
                color: var(--gris-600);
                margin-top: 2px;
            }

            /* Botones del header */
            .header-actions {
                margin-left: auto;
                display: flex;
                align-items: center;
                gap: 10px;
            }

            .header-btn {
                font-size: 12.5px;
                color: var(--gris-700);
                text-decoration: none;
                padding: 6px 12px;
                border: 1px solid var(--gris-300);
                border-radius: 4px;
                display: flex;
                align-items: center;
                gap: 5px;
                transition: all .15s;
                white-space: nowrap;
                background: var(--blanco);
            }

            .header-btn:hover {
                color: var(--azul-medio);
                border-color: var(--azul-medio);
                background: var(--azul-claro);
            }

            .header-btn.btn-home {
                color: var(--azul-medio);
                border-color: var(--azul-medio);
                background: var(--azul-claro);
            }

            .header-btn.btn-home:hover {
                background: var(--azul-medio);
                color: var(--blanco);
            }

            .header-btn.btn-admin {
                color: var(--gris-400);
                border-color: var(--gris-200);
            }

            .header-btn.btn-admin:hover {
                color: var(--azul-medio);
                border-color: var(--azul-medio);
                background: var(--azul-claro);
            }

            /* ═══ ÁREA PRINCIPAL ═══ */
            .main {
                flex: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 48px 24px;
            }
            .consulta-card {
                background: var(--blanco);
                border-radius: 12px;
                box-shadow: 0 4px 24px rgba(0,0,0,.08), 0 1px 4px rgba(0,0,0,.04);
                width: 100%;
                max-width: 520px;
                overflow: hidden;
            }
            .card-header {
                background: linear-gradient(135deg, var(--azul-oscuro) 0%, var(--azul-medio) 100%);
                padding: 32px 36px 28px;
                text-align: center;
            }
            .card-header .icon-circle {
                width: 64px;
                height: 64px;
                background: rgba(255,255,255,.15);
                border-radius: 50%;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 14px;
            }
            .card-header .icon-circle i {
                color: var(--blanco);
                font-size: 28px;
            }
            .card-header h2 {
                font-family: var(--font-serif);
                font-size: 22px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1.3;
                margin-bottom: 6px;
            }
            .card-header p {
                font-size: 14px;
                color: rgba(255,255,255,.75);
                line-height: 1.5;
            }

            .card-body {
                padding: 32px 36px 36px;
            }

            /* Instrucción */
            .instruccion {
                font-size: 14px;
                color: var(--gris-600);
                line-height: 1.6;
                margin-bottom: 24px;
                padding-bottom: 20px;
                border-bottom: 1px solid var(--gris-200);
            }

            /* Campo de formulario */
            .field-label {
                display: block;
                font-size: 12.5px;
                font-weight: 600;
                color: var(--gris-700);
                text-transform: uppercase;
                letter-spacing: .6px;
                margin-bottom: 8px;
            }
            .input-cedula-wrap {
                display: flex;
                align-items: center;
                border: 2px solid var(--gris-300);
                border-radius: 8px;
                overflow: hidden;
                transition: border-color .15s, box-shadow .15s;
                background: var(--blanco);
            }
            .input-cedula-wrap:focus-within {
                border-color: var(--azul-vivo);
                box-shadow: 0 0 0 4px rgba(37,99,235,.1);
            }
            .input-cedula-wrap .ic-prefix {
                padding: 14px 16px;
                background: var(--gris-100);
                border-right: 1.5px solid var(--gris-200);
                color: var(--gris-600);
                font-size: 16px;
            }
            .input-cedula-wrap input[type="text"] {
                flex: 1;
                padding: 14px 16px;
                border: none;
                font-family: var(--font-body);
                font-size: 18px;
                font-weight: 500;
                color: var(--negro);
                letter-spacing: 1px;
                background: transparent;
            }
            .input-cedula-wrap input[type="text"]:focus {
                outline: none;
            }
            .input-cedula-wrap input[type="text"]::placeholder {
                color: var(--gris-300);
                letter-spacing: 0;
                font-weight: 400;
                font-size: 15px;
            }

            /* CAPTCHA */
            .captcha-row {
                display: flex;
                align-items: center;
                gap: 12px;
                margin-top: 20px;
                margin-bottom: 8px;
            }
            .captcha-question {
                font-family: var(--font-body);
                font-size: 15px;
                font-weight: 600;
                color: var(--gris-700);
                background: var(--gris-100);
                border: 1.5px solid var(--gris-200);
                border-radius: 6px;
                padding: 10px 16px;
                white-space: nowrap;
                letter-spacing: .5px;
            }
            .captcha-question .eq {
                color: var(--gris-400);
                margin: 0 4px;
            }
            .captcha-hint {
                font-size: 11.5px;
                color: var(--gris-400);
                font-style: italic;
            }
            .captcha-input {
                width: 80px;
                text-align: center;
                padding: 10px;
                border: 2px solid var(--gris-300);
                border-radius: 6px;
                font-size: 18px;
                font-weight: 700;
                font-family: var(--font-body);
                color: var(--negro);
                transition: border-color .15s, box-shadow .15s;
            }
            .captcha-input:focus {
                outline: none;
                border-color: var(--azul-vivo);
                box-shadow: 0 0 0 3px rgba(37,99,235,.1);
            }

            /* Alerta de error */
            .alert-error {
                background: var(--rojo-claro);
                border: 1px solid #FECACA;
                border-left: 4px solid var(--rojo);
                border-radius: 6px;
                padding: 12px 16px;
                font-size: 13.5px;
                color: var(--rojo);
                display: flex;
                align-items: center;
                gap: 10px;
                margin-bottom: 20px;
            }
            .alert-error i {
                flex-shrink: 0;
                font-size: 15px;
            }

            /* Botón consultar */
            .btn-consultar {
                width: 100%;
                padding: 15px;
                background: var(--azul-oscuro);
                color: var(--blanco);
                border: none;
                border-radius: 8px;
                font-family: var(--font-body);
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                letter-spacing: .3px;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                margin-top: 28px;
                transition: background .15s, transform .1s;
                box-shadow: 0 4px 12px rgba(0,51,102,.2);
            }
            .btn-consultar:hover  {
                background: var(--azul-medio);
            }
            .btn-consultar:active {
                transform: scale(.99);
            }

            /* Nota legal */
            .nota-legal {
                margin-top: 20px;
                font-size: 11.5px;
                color: var(--gris-400);
                text-align: center;
                line-height: 1.6;
            }
            .nota-legal i {
                margin-right: 4px;
            }

            /* ═══ FOOTER ═══ */
            .site-footer {
                background: var(--blanco);
                border-top: 1px solid var(--gris-200);
                padding: 16px 0;
                text-align: center;
                font-size: 12px;
                color: var(--gris-400);
            }

            /* ═══ RESPONSIVE ═══ */
            @media (max-width: 540px) {
                .card-header {
                    padding: 28px 24px 24px;
                }
                .card-body   {
                    padding: 24px 24px 28px;
                }
                .header-btn .label {
                    display: none;
                }
                .header-actions {
                    gap: 6px;
                }
                .header-btn {
                    padding: 6px 10px;
                }
            }
        </style>
    </head>
    <body>

        <!-- Barra institucional -->
        <div class="gov-bar">
            República de Colombia
            <span>·</span>
            Registraduría Nacional del Estado Civil
            <span>·</span>
            Municipal de Nobsa, Boyacá
        </div>

        <!-- Header -->
        <header class="site-header">
            <div class="header-inner">
                <div class="header-escudo"><i class="fas fa-landmark"></i></div>
                <div class="header-text">
                    <h1>Registraduría Municipal de Nobsa</h1>
                    <p>Boyacá, Colombia &mdash; Consulta de Puesto de Votación</p>
                </div>

                <!-- Botones del header -->
                <div class="header-actions">
                    <a href="${pageContext.request.contextPath}/" class="header-btn btn-home">
                        <i class="fas fa-home"></i>
                        <span class="label">Inicio</span>
                    </a>
                    <a href="${pageContext.request.contextPath}/admin/login" class="header-btn btn-admin">
                        <i class="fas fa-lock"></i>
                        <span class="label">Panel Administrativo</span>
                    </a>
                </div>
            </div>
        </header>

        <!-- Contenido principal -->
        <main class="main">
            <div class="consulta-card">

                <div class="card-header">
                    <div class="icon-circle"><i class="fas fa-vote-yea"></i></div>
                    <h2>Consulte su Puesto<br>de Votación</h2>
                    <p>Ingrese su número de cédula para conocer<br>la zona, puesto y mesa donde debe votar.</p>
                </div>

                <div class="card-body">
                    <p class="instruccion">
                        Ingrese su número de documento de identidad <strong>sin puntos ni espacios</strong>.
                        El sistema le informará su lugar de votación registrado.
                    </p>

                    <%-- Mensaje de error (CAPTCHA incorrecto u otro error) --%>
                    <c:if test="${not empty errorCaptcha}">
                        <div class="alert-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <span>${errorCaptcha}</span>
                        </div>
                    </c:if>

                    <form action="${pageContext.request.contextPath}/consulta-mesa" method="post" autocomplete="off" novalidate>

                        <%-- Campo cédula --%>
                        <label class="field-label" for="documento">
                            <i class="fas fa-id-card" style="margin-right:4px;"></i>
                            Número de Documento
                        </label>
                        <div class="input-cedula-wrap">
                            <span class="ic-prefix"><i class="fas fa-fingerprint"></i></span>
                            <input type="text"
                                   id="documento"
                                   name="documento"
                                   inputmode="numeric"
                                   pattern="[0-9]+"
                                   maxlength="12"
                                   placeholder="Ej. 1052345678"
                                   value="${documentoPrevio}"
                                   required
                                   autofocus>
                        </div>

                        <%-- CAPTCHA de Google reCAPTCHA v2 --%>
                        <div style="margin-top:24px;">
                            <label class="field-label">
                                <i class="fas fa-shield-alt" style="margin-right:4px;"></i>
                                Verificación de seguridad
                            </label>

                            <!-- Widget de reCAPTCHA -->
                            <div class="g-recaptcha" 
                                 data-sitekey="6Lek_sIsAAAAAODz91Q6HbcsZGey-zFRMkJF1Kog"
                                 data-callback="recaptchaCallback"
                                 data-expired-callback="recaptchaExpired">
                            </div>

                            <!-- Mensaje de error -->
                            <div id="recaptcha-error" style="color:var(--rojo);font-size:12px;margin-top:6px;display:none;">
                                <i class="fas fa-exclamation-circle"></i> 
                                Por favor completa la verificación de seguridad
                            </div>

                            <p class="captcha-hint">
                                <i class="fas fa-info-circle"></i>
                                Esta verificación confirma que usted es una persona, no un programa.
                            </p>
                        </div>

                        <!-- Script de Google reCAPTCHA -->
                        <script src="https://www.google.com/recaptcha/api.js" async defer></script>

                        <script>
                            function recaptchaCallback(response) {
                                document.getElementById('recaptcha-error').style.display = 'none';
                            }

                            function recaptchaExpired() {
                                document.getElementById('recaptcha-error').style.display = 'block';
                            }

                            // Validar antes de enviar
                            document.querySelector('form').addEventListener('submit', function (e) {
                                const recaptchaResponse = grecaptcha.getResponse();
                                if (recaptchaResponse.length === 0) {
                                    e.preventDefault();
                                    document.getElementById('recaptcha-error').style.display = 'block';
                                    return false;
                                }
                                return true;
                            });
                        </script>

                        <%-- Botón --%>
                        <button type="submit" class="btn-consultar">
                            <i class="fas fa-search"></i>
                            Consultar Puesto de Votación
                        </button>

                    </form>

                    <p class="nota-legal">
                        <i class="fas fa-lock"></i>
                        Su consulta es confidencial. Los datos son de uso exclusivo para orientación electoral.
                    </p>
                </div>
            </div>
        </main>

        <!-- Footer -->
        <footer class="site-footer">
            Registraduría Municipal de Nobsa &mdash; Boyacá, Colombia
            &nbsp;&bull;&nbsp;
            Sistema de Información Electoral
            &nbsp;&bull;&nbsp;
            SENA · ADSO · CIMM 2026
        </footer>
    </body>
</html>