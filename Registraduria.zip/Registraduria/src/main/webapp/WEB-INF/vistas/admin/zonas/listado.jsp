<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="pageTitle" value="Zonas de Votación" scope="request"/>
<c:set var="activeSection" value="zonas" scope="request"/>
<%@ include file="/WEB-INF/vistas/admin/adminLayout.jsp" %>

<style>
    .page-content {
        padding: 28px;
    }
    .page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
    }
    .page-header h2 {
        font-family: var(--font-display);
        font-size: 22px;
        font-weight: 700;
        color: var(--negro);
    }
    .page-header .page-subtitle {
        font-size: 13px;
        color: var(--gris-600);
        margin-top: 2px;
    }

    .toolbar {
        background: var(--blanco);
        border-radius: 8px;
        border: 1px solid var(--gris-200);
        padding: 14px 20px;
        display: flex;
        align-items: center;
        gap: 14px;
        margin-bottom: 16px;
        box-shadow: var(--shadow-sm);
    }
    .search-input {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--gris-100);
        border: 1.5px solid var(--gris-200);
        border-radius: 6px;
        padding: 8px 14px;
        transition: border-color .15s;
    }
    .search-input:focus-within {
        border-color: var(--azul-vivo);
        background: var(--blanco);
    }
    .search-input i {
        color: var(--gris-400);
        font-size: 14px;
    }
    .search-input input {
        border: none;
        background: transparent;
        font-family: var(--font-body);
        font-size: 14px;
        color: var(--negro);
        width: 100%;
    }
    .search-input input:focus {
        outline: none;
    }
    .search-input input::placeholder {
        color: var(--gris-400);
    }

    .table-card {
        background: var(--blanco);
        border-radius: 8px;
        border: 1px solid var(--gris-200);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }
    .table-responsive {
        overflow-x: auto;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    thead tr {
        background: var(--gris-100);
        border-bottom: 2px solid var(--gris-200);
    }
    thead th {
        padding: 11px 16px;
        font-size: 11.5px;
        font-weight: 700;
        letter-spacing: .8px;
        text-transform: uppercase;
        color: var(--gris-600);
        text-align: left;
        white-space: nowrap;
    }
    thead th.col-acciones {
        text-align: right;
    }
    tbody tr {
        border-bottom: 1px solid var(--gris-200);
        transition: background .12s;
    }
    tbody tr:last-child {
        border-bottom: none;
    }
    tbody tr:hover {
        background: var(--azul-claro);
    }
    tbody td {
        padding: 12px 16px;
        font-size: 14px;
        vertical-align: middle;
    }
    .zona-celda .zona-nombre {
        font-weight: 600;
    }
    .zona-celda .zona-puesto {
        font-size: 12px;
        color: var(--gris-600);
        margin-top: 1px;
    }
    .zona-celda .zona-dir {
        font-size: 11.5px;
        color: var(--gris-400);
        margin-top: 2px;
    }
    .ciudad-chip {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        background: var(--azul-claro);
        color: var(--azul-oscuro);
        padding: 3px 9px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
    }
    .actions {
        display: flex;
        justify-content: flex-end;
        gap: 6px;
    }
    .empty-state {
        text-align: center;
        padding: 48px 24px;
        color: var(--gris-600);
    }
    .empty-state i {
        font-size: 36px;
        color: var(--gris-300);
        margin-bottom: 12px;
        display: block;
    }
</style>

<div class="page-content">
    <div class="page-header">
        <div>
            <h2>
                <i class="fas fa-map-marked-alt" style="color:var(--azul-medio);margin-right:10px;font-size:20px;"></i>
                Zonas de Votación
            </h2>
            <p class="page-subtitle">Zonas, puestos de votación y direcciones del municipio de Nobsa</p>
        </div>
        <button class="btn btn-primary" onclick="abrirModalCrearZona()">
            <i class="fas fa-plus"></i> Nueva Zona
        </button>
    </div>

    <c:if test="${not empty successMsg}">
        <div class="toast toast-success" id="flashToast" style="position:relative;margin-bottom:16px;animation:none;">
            <i class="fas fa-check-circle"></i>
            <span class="toast-msg">${successMsg}</span>
            <button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
        </div>
    </c:if>

    <div class="toolbar">
        <div class="search-input">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por nombre de zona, puesto o dirección…">
        </div>
        <select id="filtroCiudad" class="form-control" style="width:auto;padding:8px 12px;">
            <option value="">Todas las ciudades</option>
            <c:forEach var="ciudad" items="${ciudades}">
                <option value="${ciudad.nombre}">${ciudad.nombre}</option>
            </c:forEach>
        </select>
    </div>

    <div class="table-card">
        <div class="table-responsive">
            <table id="tablaZonas">
                <thead>
                    <tr>
                        <th>Zona / Puesto de Votación</th>
                        <th>Ciudad</th>
                        <th>N.° Mesas</th>
                        <th class="col-acciones">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <c:choose>
                        <c:when test="${empty zonas}">
                            <tr>
                                <td colspan="4">
                                    <div class="empty-state">
                                        <i class="fas fa-map-marked-alt"></i>
                                        <p>No hay zonas de votación registradas.</p>
                                    </div>
                                </td>
                            </tr>
                        </c:when>
                        <c:otherwise>
                            <c:forEach var="z" items="${zonas}">
                                <tr>
                                    <td>
                                        <div class="zona-celda">
                                            <div class="zona-nombre">${z.nombreZona}</div>
                                            <div class="zona-puesto">
                                                <i class="fas fa-school" style="font-size:11px;margin-right:3px;"></i>
                                                ${z.puestoVotacion}
                                            </div>
                                            <div class="zona-dir">
                                                <i class="fas fa-map-pin" style="font-size:10px;margin-right:3px;"></i>
                                                ${z.direccion}
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="ciudad-chip">
                                            <i class="fas fa-city" style="font-size:10px;"></i>
                                            ${z.ciudad}
                                        </span>
                                    </td>
                                    <td>
                                        <%-- numeroMesas viene del servlet como COUNT desde la BD --%>
                                        <span style="font-weight:600;">${z.numeroMesas}</span>
                                        <a href="${pageContext.request.contextPath}/admin/mesas?idZona=${z.id}"
                                           style="font-size:12px;color:var(--azul-medio);margin-left:6px;text-decoration:none;">
                                            <i class="fas fa-external-link-alt" style="font-size:10px;"></i> Ver mesas
                                        </a>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <button class="btn btn-secondary btn-sm btn-icon" title="Editar zona"
                                                    onclick="abrirModalEditarZona(
                                                    ${z.id}, '${z.idCiudad}',
                                                                    '${z.nombreZona}', '${z.puestoVotacion}', '${z.direccion}')">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-danger btn-sm btn-icon" title="Eliminar zona"
                                                    onclick="confirmarEliminar(${z.id}, '${z.nombreZona}')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal-overlay" id="modalZona">
    <div class="modal">
        <div class="modal__header">
            <i class="fas fa-map-marked-alt" style="color:var(--azul-medio);"></i>
            <h3 id="modalZonaTitulo">Nueva Zona de Votación</h3>
            <button class="modal-close" onclick="cerrarModal('modalZona')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal__body">
            <form id="formZona"
                  action="${pageContext.request.contextPath}/admin/zonas"
                  method="post" novalidate>
                <input type="hidden" name="id" id="zonaId">

                <div class="form-row">
                    <div class="form-group">
                        <label for="idCiudadZona">Ciudad <span class="req">*</span></label>
                        <select id="idCiudadZona" name="idCiudad" class="form-control" required>
                            <option value="">— Seleccione ciudad —</option>
                            <c:forEach var="ciudad" items="${ciudades}">
                                <option value="${ciudad.id}">${ciudad.nombre} (DANE: ${ciudad.codigoDane})</option>
                            </c:forEach>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="nombreZona">Nombre de la Zona <span class="req">*</span></label>
                        <input type="text" id="nombreZona" name="nombreZona"
                               class="form-control" maxlength="80"
                               placeholder="Ej: Zona Centro, Zona Heroica…" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="puestoVotacion">Puesto de Votación <span class="req">*</span></label>
                        <input type="text" id="puestoVotacion" name="puestoVotacion"
                               class="form-control" maxlength="120"
                               placeholder="Ej: Institución Educativa Nobsa" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="direccionZona">Dirección <span class="req">*</span></label>
                        <input type="text" id="direccionZona" name="direccion"
                               class="form-control" maxlength="150"
                               placeholder="Ej: Calle 5 # 4-32, Centro" required>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal__footer">
            <button class="btn btn-secondary" onclick="cerrarModal('modalZona')">Cancelar</button>
            <button class="btn btn-primary" onclick="submitFormZona()">
                <i class="fas fa-save"></i> <span id="btnZonaLabel">Guardar</span>
            </button>
        </div>
    </div>
</div>

<form id="formEliminar" action="${pageContext.request.contextPath}/admin/zonas" method="post" style="display:none;">
    <input type="hidden" name="action" value="eliminar">
    <input type="hidden" name="id" id="inputEliminarId">
</form>

<div class="confirm-overlay" id="confirmEliminar">
    <div class="confirm-box">
        <div class="confirm-icon"><i class="fas fa-trash-alt"></i></div>
        <h3>¿Eliminar zona?</h3>
        <p id="confirmZonaMsg">Solo se puede eliminar si no tiene mesas de votación asociadas.</p>
        <div class="confirm-actions">
            <button class="btn btn-secondary" onclick="cerrarConfirm()">Cancelar</button>
            <button class="btn btn-danger" id="btnConfirmEliminar" type="button">
                <i class="fas fa-trash"></i> Eliminar
            </button>
        </div>
    </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script>
    const CTX = '<%= request.getContextPath()%>';

    function abrirModal(id) {
        document.getElementById(id).classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function cerrarModal(id) {
        document.getElementById(id).classList.remove('active');
        document.body.style.overflow = '';
    }
    document.querySelectorAll('.modal-overlay,.confirm-overlay').forEach(o => {
        o.addEventListener('click', e => {
            if (e.target === o)
                cerrarModal(o.id);
        });
    });

    function abrirModalCrearZona() {
        document.getElementById('modalZonaTitulo').textContent = 'Nueva Zona de Votación';
        document.getElementById('btnZonaLabel').textContent = 'Guardar';
        document.getElementById('formZona').reset();
        document.getElementById('zonaId').value = '';
        abrirModal('modalZona');
    }

    function abrirModalEditarZona(id, idCiudad, nombre, puesto, dir) {
        document.getElementById('modalZonaTitulo').textContent = 'Editar Zona de Votación';
        document.getElementById('btnZonaLabel').textContent = 'Actualizar';
        document.getElementById('zonaId').value = id;
        document.getElementById('idCiudadZona').value = idCiudad;
        document.getElementById('nombreZona').value = nombre;
        document.getElementById('puestoVotacion').value = puesto;
        document.getElementById('direccionZona').value = dir;
        abrirModal('modalZona');
    }

    function submitFormZona() {
        const form = document.getElementById('formZona');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        form.submit();
    }

    function confirmarEliminar(id, nombre) {
        document.getElementById('confirmZonaMsg').innerHTML =
                `¿Eliminar la zona <strong>${nombre}</strong>?<br>Solo si no tiene mesas asociadas.`;
        document.getElementById('inputEliminarId').value = id;

        const btnEliminar = document.getElementById('btnConfirmEliminar');
        btnEliminar.onclick = function () {
            document.getElementById('formEliminar').submit();
        };

        document.getElementById('confirmEliminar').classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function cerrarConfirm() {
        document.getElementById('confirmEliminar').classList.remove('active');
        document.body.style.overflow = '';
    }

    document.getElementById('searchInput').addEventListener('input', filtrar);
    document.getElementById('filtroCiudad').addEventListener('change', filtrar);
    function filtrar() {
        const q = document.getElementById('searchInput').value.toLowerCase();
        const c = document.getElementById('filtroCiudad').value.toLowerCase();
        document.querySelectorAll('#tablaZonas tbody tr').forEach(row => {
            const t = row.textContent.toLowerCase();
            row.style.display = (t.includes(q) && (c === '' || t.includes(c))) ? '' : 'none';
        });
    }

    const flash = document.getElementById('flashToast');
    if (flash)
        setTimeout(() => flash.remove(), 4500);
</script>
</body>
</html>