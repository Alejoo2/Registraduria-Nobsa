<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<c:set var="pageTitle" value="Ciudadanos" scope="request"/>
<c:set var="activeSection" value="ciudadanos" scope="request"/>
<%@ include file="/WEB-INF/vistas/admin/adminLayout.jsp" %>

<style>
    .page-content {
        padding: 28px;
    }
    .page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
    }
    .page-header h2 {
        font-family: var(--font-display);
        font-size: 22px;
        font-weight: 700;
        color: var(--negro);
    }
    .page-header .page-subtitle {
        font-size: 13px;
        color: var(--gris-600);
        margin-top: 2px;
    }

    /* ── TOOLBAR ── */
    .toolbar {
        background: var(--blanco);
        border-radius: 8px;
        border: 1px solid var(--gris-200);
        padding: 14px 20px;
        display: flex;
        align-items: center;
        gap: 14px;
        margin-bottom: 16px;
        box-shadow: var(--shadow-sm);
    }
    .search-input {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--gris-100);
        border: 1.5px solid var(--gris-200);
        border-radius: 6px;
        padding: 8px 14px;
        transition: border-color .15s;
    }
    .search-input:focus-within {
        border-color: var(--azul-vivo);
        background: var(--blanco);
    }
    .search-input i {
        color: var(--gris-400);
        font-size: 14px;
        flex-shrink: 0;
    }
    .search-input input {
        border: none;
        background: transparent;
        font-family: var(--font-body);
        font-size: 14px;
        color: var(--negro);
        width: 100%;
    }
    .search-input input:focus {
        outline: none;
    }
    .search-input input::placeholder {
        color: var(--gris-400);
    }
    .toolbar .total-badge {
        font-size: 12.5px;
        color: var(--gris-600);
        background: var(--gris-100);
        padding: 5px 12px;
        border-radius: 20px;
        border: 1px solid var(--gris-200);
        white-space: nowrap;
    }

    /* ── TABLA ── */
    .table-card {
        background: var(--blanco);
        border-radius: 8px;
        border: 1px solid var(--gris-200);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }
    .table-responsive {
        overflow-x: auto;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    thead tr {
        background: var(--gris-100);
        border-bottom: 2px solid var(--gris-200);
    }
    thead th {
        padding: 11px 16px;
        font-size: 11.5px;
        font-weight: 700;
        letter-spacing: .8px;
        text-transform: uppercase;
        color: var(--gris-600);
        text-align: left;
        white-space: nowrap;
    }
    thead th.col-acciones {
        text-align: right;
    }
    tbody tr {
        border-bottom: 1px solid var(--gris-200);
        transition: background .12s;
    }
    tbody tr:last-child {
        border-bottom: none;
    }
    tbody tr:hover {
        background: var(--azul-claro);
    }
    tbody td {
        padding: 12px 16px;
        font-size: 14px;
        color: var(--negro);
        vertical-align: middle;
    }
    tbody td .doc-num {
        font-family: monospace;
        font-size: 13.5px;
        background: var(--gris-100);
        padding: 2px 8px;
        border-radius: 4px;
        color: var(--gris-800);
    }
    tbody td .nombre-celda .nombre {
        font-weight: 600;
    }
    tbody td .nombre-celda .vereda {
        font-size: 12px;
        color: var(--gris-600);
        margin-top: 1px;
    }
    tbody td .actions {
        display: flex;
        justify-content: flex-end;
        gap: 6px;
    }
    .empty-state {
        text-align: center;
        padding: 48px 24px;
        color: var(--gris-600);
    }
    .empty-state i {
        font-size: 36px;
        color: var(--gris-300);
        margin-bottom: 12px;
    }
    .empty-state p {
        font-size: 15px;
    }

    /* ── PAGINACIÓN ── */
    .pagination-bar {
        padding: 14px 20px;
        border-top: 1px solid var(--gris-200);
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: var(--gris-100);
    }
    .pagination-bar .info {
        font-size: 12.5px;
        color: var(--gris-600);
    }
    .pagination-controls {
        display: flex;
        gap: 4px;
    }
    .page-btn {
        width: 32px;
        height: 32px;
        border-radius: 5px;
        border: 1.5px solid var(--gris-300);
        background: var(--blanco);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 13px;
        color: var(--gris-800);
        cursor: pointer;
        text-decoration: none;
        transition: all .12s;
    }
    .page-btn:hover {
        background: var(--azul-claro);
        border-color: var(--azul-vivo);
        color: var(--azul-oscuro);
    }
    .page-btn.active {
        background: var(--azul-oscuro);
        border-color: var(--azul-oscuro);
        color: var(--blanco);
    }
    .page-btn:disabled, .page-btn.disabled {
        opacity: .4;
        pointer-events: none;
    }
</style>

<div class="page-content">
    <div class="page-header">
        <div>
            <h2><i class="fas fa-users" style="color:var(--azul-medio);margin-right:10px;font-size:20px;"></i>Ciudadanos</h2>
            <p class="page-subtitle">Gestión del registro civil de Nobsa, Boyacá</p>
        </div>
        <button class="btn btn-primary" onclick="abrirModalCrear()">
            <i class="fas fa-plus"></i> Registrar Ciudadano
        </button>
    </div>

    <%-- ── MENSAJES FLASH ── --%>
    <c:if test="${not empty successMsg}">
        <div class="toast toast-success" id="flashToast" style="position:relative;margin-bottom:16px;animation:none;">
            <i class="fas fa-check-circle"></i>
            <span class="toast-msg">${successMsg}</span>
            <button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
        </div>
    </c:if>
    <c:if test="${not empty errorMsg}">
        <div class="toast toast-error" id="flashToast" style="position:relative;margin-bottom:16px;animation:none;">
            <i class="fas fa-exclamation-circle"></i>
            <span class="toast-msg">${errorMsg}</span>
            <button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
        </div>
    </c:if>

    <%-- ── TOOLBAR ── --%>
    <div class="toolbar">
        <div class="search-input">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por nombre, apellido o cédula…">
        </div>
        <span class="total-badge">
            <i class="fas fa-users" style="margin-right:5px;"></i>
            <span id="totalCount">${fn:length(ciudadanos)}</span> registros
        </span>
        <button class="btn btn-secondary btn-sm" onclick="exportarCSV()">
            <i class="fas fa-file-export"></i> Exportar
        </button>
    </div>

    <%-- ── TABLA ── --%>
    <div class="table-card">
        <div class="table-responsive">
            <table id="tablaCiudadanos">
                <thead>
                    <tr>
                        <th>Cédula</th>
                        <th>Nombre Completo</th>
                        <th>Fecha Nac.</th>
                        <th>Teléfono</th>
                        <th>Mesa</th>
                        <th class="col-acciones">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <c:choose>
                        <c:when test="${empty ciudadanos}">
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <i class="fas fa-users"></i>
                                        <p>No hay ciudadanos registrados aún.</p>
                                    </div>
                                </td>
                            </tr>
                        </c:when>
                        <c:otherwise>
                            <c:forEach var="c" items="${ciudadanos}">
                                <tr>
                                    <td><span class="doc-num">${c.numeroDocumento}</span></td>
                                    <td>
                                        <div class="nombre-celda">
                                            <div class="nombre">${c.nombres} ${c.apellidos}</div>
                                            <div class="vereda">
                                                <i class="fas fa-map-pin" style="font-size:10px;"></i>
                                                ${c.veredaBarrio}
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty c.fechaNacimiento}">
                                                ${c.fechaNacimiento}
                                            </c:when>
                                            <c:otherwise>
                                                <span style="color:var(--gris-400);">-</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty c.telefono}">${c.telefono}</c:when>
                                            <c:otherwise><span style="color:var(--gris-400);">—</span></c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty c.idMesa}">
                                                <span class="badge badge-vigente">
                                                    <i class="fas fa-check"></i> Mesa ${c.idMesa}
                                                </span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge badge-pendiente">
                                                    <i class="fas fa-clock"></i> Sin asignar
                                                </span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <button class="btn btn-secondary btn-sm btn-icon"
                                                    title="Ver documentos"
                                                    onclick="verDocumentos(${c.id})">
                                                <i class="fas fa-id-card"></i>
                                            </button>
                                            <button class="btn btn-secondary btn-sm btn-icon"
                                                    title="Editar ciudadano"
                                                    onclick="abrirModalEditar(
                                                    ${c.id}, '${c.numeroDocumento}',
                                                                    '${c.nombres}', '${c.apellidos}',
                                                                    '${c.fechaNacimiento}', '${c.veredaBarrio}',
                                                                    '${c.telefono}', '${c.correo}',
                                                                    '${c.idMesa != null ? c.idMesa : ''}')">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-danger btn-sm btn-icon"
                                                    title="Eliminar ciudadano"
                                                    onclick="confirmarEliminar(${c.id}, '${c.nombres} ${c.apellidos}')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>

        <%-- ── PAGINACIÓN ── --%>
        <div class="pagination-bar">
            <span class="info" id="paginationInfo">Mostrando todos los registros</span>
            <div class="pagination-controls" id="paginationControls"></div>
        </div>
    </div>
</div>

<%-- ═══════════════════════════════════════════════════
     MODAL: CREAR / EDITAR CIUDADANO
     ═══════════════════════════════════════════════════ --%>
<div class="modal-overlay" id="modalCiudadano">
    <div class="modal">
        <div class="modal__header">
            <i class="fas fa-user-edit" style="color:var(--azul-medio);"></i>
            <h3 id="modalTitulo">Registrar Ciudadano</h3>
            <button class="modal-close" onclick="cerrarModal('modalCiudadano')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal__body">
            <form id="formCiudadano"
                  action="${pageContext.request.contextPath}/admin/ciudadanos"
                  method="post" novalidate>
                <input type="hidden" name="id" id="ciudadanoId">

                <div class="form-row cols-2">
                    <div class="form-group">
                        <label for="nombres">Nombres <span class="req">*</span></label>
                        <input type="text" id="nombres" name="nombres"
                               class="form-control" maxlength="80" required>
                    </div>
                    <div class="form-group">
                        <label for="apellidos">Apellidos <span class="req">*</span></label>
                        <input type="text" id="apellidos" name="apellidos"
                               class="form-control" maxlength="80" required>
                    </div>
                </div>

                <div class="form-row cols-2">
                    <div class="form-group">
                        <label for="numeroDocumento">N.º de Cédula <span class="req">*</span></label>
                        <input type="text" id="numeroDocumento" name="numeroDocumento"
                               class="form-control" maxlength="20"
                               inputmode="numeric" required>
                    </div>
                    <div class="form-group">
                        <label for="fechaNacimiento">Fecha de Nacimiento <span class="req">*</span></label>
                        <input type="date" id="fechaNacimiento" name="fechaNacimiento"
                               class="form-control" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="veredaBarrio">Vereda / Barrio de Residencia <span class="req">*</span></label>
                        <input type="text" id="veredaBarrio" name="veredaBarrio"
                               class="form-control" maxlength="80"
                               placeholder="Ej: Centro, Heroica, San Martín…" required>
                    </div>
                </div>

                <div class="form-row cols-2">
                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <input type="tel" id="telefono" name="telefono"
                               class="form-control" maxlength="20"
                               placeholder="Ej: 3101234567">
                    </div>
                    <div class="form-group">
                        <label for="correo">Correo Electrónico</label>
                        <input type="email" id="correo" name="correo"
                               class="form-control" maxlength="100"
                               placeholder="opcional@ejemplo.com">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="idMesa">Mesa de Votación Asignada</label>
                        <select id="idMesa" name="idMesa" class="form-control">
                            <option value="">— Sin asignar —</option>
                            <c:forEach var="m" items="${mesas}">
                                <option value="${m.id}">
                                    Mesa ${m.numeroMesa} — ${m.nombreZona} (cap. ${m.capacidad})
                                </option>
                            </c:forEach>
                        </select>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal__footer">
            <button class="btn btn-secondary" onclick="cerrarModal('modalCiudadano')">
                <i class="fas fa-times"></i> Cancelar
            </button>
            <button class="btn btn-primary" onclick="submitFormCiudadano()">
                <i class="fas fa-save"></i> <span id="btnGuardarLabel">Guardar</span>
            </button>
        </div>
    </div>
</div>

<%-- ═══════════════════════════════════════════════════
     CONFIRM DIALOG: ELIMINAR
     ═══════════════════════════════════════════════════ --%>
<div class="confirm-overlay" id="confirmEliminar">
    <div class="confirm-box">
        <div class="confirm-icon"><i class="fas fa-trash-alt"></i></div>
        <h3>¿Eliminar ciudadano?</h3>
        <p id="confirmMsg">
            Esta acción no se puede deshacer.<br>
            Solo se puede eliminar si el ciudadano <strong>no tiene documentos expedidos</strong>.
        </p>
        <div class="confirm-actions">
            <button class="btn btn-secondary" onclick="cerrarConfirm()">
                <i class="fas fa-times"></i> Cancelar
            </button>
            <a class="btn btn-danger" id="btnConfirmEliminar" href="#">
                <i class="fas fa-trash"></i> Sí, eliminar
            </a>
        </div>
    </div>
</div>

<%-- ── TOAST CONTAINER ── --%>
<div class="toast-container" id="toastContainer"></div>

<%-- ── JAVASCRIPT ── --%>
<script>
    // ✅ CTX definido con JSP expression para evitar problemas de evaluación
    const CTX = '<%= request.getContextPath()%>';

    /* ── MODAL HELPERS ── */
    function abrirModal(id) {
        document.getElementById(id).classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function cerrarModal(id) {
        document.getElementById(id).classList.remove('active');
        document.body.style.overflow = '';
    }
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', e => {
            if (e.target === overlay)
                cerrarModal(overlay.id);
        });
    });

    /* ── ABRIR MODAL CREAR ── */
    function abrirModalCrear() {
        document.getElementById('modalTitulo').textContent = 'Registrar Ciudadano';
        document.getElementById('btnGuardarLabel').textContent = 'Registrar';
        document.getElementById('formCiudadano').reset();
        document.getElementById('ciudadanoId').value = '';
        document.getElementById('numeroDocumento').removeAttribute('readonly');
        abrirModal('modalCiudadano');
    }

    /* ── ABRIR MODAL EDITAR ── */
    function abrirModalEditar(id, doc, nombres, apellidos, fechaNac, vereda, tel, correo, idMesa) {
        document.getElementById('modalTitulo').textContent = 'Editar Ciudadano';
        document.getElementById('btnGuardarLabel').textContent = 'Actualizar';
        document.getElementById('ciudadanoId').value = id;
        document.getElementById('numeroDocumento').value = doc;
        document.getElementById('numeroDocumento').setAttribute('readonly', true);
        document.getElementById('nombres').value = nombres;
        document.getElementById('apellidos').value = apellidos;
        document.getElementById('fechaNacimiento').value = fechaNac;
        document.getElementById('veredaBarrio').value = vereda;
        document.getElementById('telefono').value = tel || '';
        document.getElementById('correo').value = correo || '';
        const selectMesa = document.getElementById('idMesa');
        selectMesa.value = (idMesa && idMesa !== 'null') ? idMesa : '';
        abrirModal('modalCiudadano');
    }

    /* ── SUBMIT FORMULARIO ── */
    function submitFormCiudadano() {
        const form = document.getElementById('formCiudadano');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        form.submit();
    }

    /* ── CONFIRM ELIMINAR ── */
    function confirmarEliminar(id, nombre) {
        document.getElementById('confirmMsg').innerHTML =
                '¿Desea eliminar a <strong>' + nombre + '</strong>?<br>' +
                'Solo se puede eliminar si no tiene documentos expedidos.';
        document.getElementById('btnConfirmEliminar').href =
                CTX + '/admin/ciudadanos?action=eliminar&id=' + id;
        document.getElementById('confirmEliminar').classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function cerrarConfirm() {
        document.getElementById('confirmEliminar').classList.remove('active');
        document.body.style.overflow = '';
    }
    document.getElementById('confirmEliminar').addEventListener('click', e => {
        if (e.target === document.getElementById('confirmEliminar'))
            cerrarConfirm();
    });

    /* ── REDIRIGIR A DOCUMENTOS DEL CIUDADANO ── */
    function verDocumentos(idCiudadano) {
        // ✅ URL completa con context path para evitar error 404
        window.location.href = CTX + '/admin/documentos?idCiudadano=' + idCiudadano;
    }

    /* ── BÚSQUEDA EN TABLA (client-side) ── */
    document.getElementById('searchInput').addEventListener('input', function () {
        const q = this.value.toLowerCase();
        const rows = document.querySelectorAll('#tablaCiudadanos tbody tr');
        let visible = 0;
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            const show = text.includes(q);
            row.style.display = show ? '' : 'none';
            if (show)
                visible++;
        });
        document.getElementById('totalCount').textContent = visible;
    });

    /* ── AUTO-DISMISS TOAST FLASH ── */
    const flash = document.getElementById('flashToast');
    if (flash)
        setTimeout(() => flash.remove(), 4500);

    /* ── TOAST UTILITARIO ── */
    function showToast(type, msg) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle'
        };
        const el = document.createElement('div');
        el.className = 'toast toast-' + type;
        el.innerHTML = '<i class="fas ' + icons[type] + '"></i>' +
                '<span class="toast-msg">' + msg + '</span>' +
                '<button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>';
        document.getElementById('toastContainer').appendChild(el);
        setTimeout(() => el.remove(), 4000);
    }

    /* ── EXPORTAR CSV ── */
    function exportarCSV() {
        const rows = Array.from(document.querySelectorAll('#tablaCiudadanos tbody tr'))
                .filter(r => r.style.display !== 'none')
                .map(r => {
                    return Array.from(r.querySelectorAll('td'))
                            .map(td => '"' + td.textContent.trim().replace(/"/g, '""') + '"')
                            .join(',');
                });
        const csv = ['Cedula,Nombre,Fecha Nac,Telefono,Mesa', ...rows].join('\n');
        const a = document.createElement('a');
        a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
        a.download = 'ciudadanos_nobsa.csv';
        a.click();
    }
</script>
</body>
</html>