<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="pageTitle" value="Mesas de Votación" scope="request"/>
<c:set var="activeSection" value="mesas" scope="request"/>
<%@ include file="/WEB-INF/vistas/admin/adminLayout.jsp" %>

<style>
    .page-content {
        padding: 28px;
    }
    .page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
    }
    .page-header h2 {
        font-family: var(--font-display);
        font-size: 22px;
        font-weight: 700;
        color: var(--negro);
    }
    .page-header .page-subtitle {
        font-size: 13px;
        color: var(--gris-600);
        margin-top: 2px;
    }

    .filtro-activo {
        background: var(--azul-claro);
        border: 1px solid #BFDBFE;
        border-radius: 8px;
        padding: 10px 16px;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 16px;
        font-size: 13px;
        color: var(--azul-oscuro);
    }
    .filtro-activo i {
        color: var(--azul-medio);
    }
    .filtro-activo a {
        margin-left: auto;
        color: var(--azul-medio);
        text-decoration: none;
        font-size: 12px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .toolbar {
        background: var(--blanco);
        border-radius: 8px;
        border: 1px solid var(--gris-200);
        padding: 14px 20px;
        display: flex;
        align-items: center;
        gap: 14px;
        margin-bottom: 16px;
        box-shadow: var(--shadow-sm);
    }
    .search-input {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--gris-100);
        border: 1.5px solid var(--gris-200);
        border-radius: 6px;
        padding: 8px 14px;
    }
    .search-input:focus-within {
        border-color: var(--azul-vivo);
        background: var(--blanco);
    }
    .search-input i {
        color: var(--gris-400);
        font-size: 14px;
    }
    .search-input input {
        border: none;
        background: transparent;
        font-family: var(--font-body);
        font-size: 14px;
        color: var(--negro);
        width: 100%;
    }
    .search-input input:focus {
        outline: none;
    }
    .search-input input::placeholder {
        color: var(--gris-400);
    }

    .table-card {
        background: var(--blanco);
        border-radius: 8px;
        border: 1px solid var(--gris-200);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }
    .table-responsive {
        overflow-x: auto;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    thead tr {
        background: var(--gris-100);
        border-bottom: 2px solid var(--gris-200);
    }
    thead th {
        padding: 11px 16px;
        font-size: 11.5px;
        font-weight: 700;
        letter-spacing: .8px;
        text-transform: uppercase;
        color: var(--gris-600);
        text-align: left;
        white-space: nowrap;
    }
    thead th.col-acciones {
        text-align: right;
    }
    tbody tr {
        border-bottom: 1px solid var(--gris-200);
        transition: background .12s;
    }
    tbody tr:last-child {
        border-bottom: none;
    }
    tbody tr:hover {
        background: var(--azul-claro);
    }
    tbody td {
        padding: 12px 16px;
        font-size: 14px;
        vertical-align: middle;
    }

    .num-mesa {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        background: var(--azul-oscuro);
        color: var(--blanco);
        border-radius: 8px;
        font-weight: 700;
        font-size: 16px;
    }
    .capacidad-bar {
        margin-top: 4px;
    }
    .capacidad-bar .bar-track {
        background: var(--gris-200);
        border-radius: 4px;
        height: 4px;
        margin-top: 4px;
    }
    .capacidad-bar .bar-fill {
        background: var(--azul-vivo);
        border-radius: 4px;
        height: 4px;
    }
    .zona-celda .zona-n {
        font-weight: 600;
    }
    .zona-celda .ciudad-n {
        font-size: 12px;
        color: var(--gris-600);
    }
    .actions {
        display: flex;
        justify-content: flex-end;
        gap: 6px;
    }
    .empty-state {
        text-align: center;
        padding: 48px 24px;
        color: var(--gris-600);
    }
    .empty-state i {
        font-size: 36px;
        color: var(--gris-300);
        margin-bottom: 12px;
        display: block;
    }

    .stats-row {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
        margin-bottom: 24px;
    }
    .stat-card {
        background: var(--blanco);
        border: 1px solid var(--gris-200);
        border-radius: 8px;
        padding: 16px 20px;
        box-shadow: var(--shadow-sm);
    }
    .stat-card .stat-label {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1px;
        text-transform: uppercase;
        color: var(--gris-400);
        margin-bottom: 6px;
    }
    .stat-card .stat-value {
        font-family: var(--font-display);
        font-size: 28px;
        font-weight: 700;
        color: var(--azul-oscuro);
    }
    .stat-card .stat-sub {
        font-size: 12px;
        color: var(--gris-600);
        margin-top: 2px;
    }
</style>

<div class="page-content">
    <div class="page-header">
        <div>
            <h2>
                <i class="fas fa-table" style="color:var(--azul-medio);margin-right:10px;font-size:20px;"></i>
                Mesas de Votación
            </h2>
            <p class="page-subtitle">Mesas habilitadas en cada zona del municipio de Nobsa</p>
        </div>
        <button class="btn btn-primary" onclick="abrirModalCrearMesa()">
            <i class="fas fa-plus"></i> Nueva Mesa
        </button>
    </div>

    <%-- ── ESTADÍSTICAS RÁPIDAS ── --%>
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-label">Total Mesas</div>
            <div class="stat-value">${fn:length(mesas)}</div>
            <div class="stat-sub">Habilitadas en Nobsa</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Capacidad Total</div>
            <%-- capacidadTotal calculada en el servlet con una suma SQL --%>
            <div class="stat-value">${capacidadTotal}</div>
            <div class="stat-sub">Votantes máximos</div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Ciudadanos Inscritos</div>
            <div class="stat-value">${ciudadanosInscritos}</div>
            <div class="stat-sub">Con mesa asignada</div>
        </div>
    </div>

    <c:if test="${not empty successMsg}">
        <div class="toast toast-success" id="flashToast" style="position:relative;margin-bottom:16px;animation:none;">
            <i class="fas fa-check-circle"></i><span class="toast-msg">${successMsg}</span>
            <button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
        </div>
    </c:if>

    <c:if test="${not empty filtroZona}">
        <div class="filtro-activo">
            <i class="fas fa-filter"></i>
            Mesas de: <strong>${filtroZona.nombreZona}</strong> — ${filtroZona.puestoVotacion}
            <a href="${pageContext.request.contextPath}/admin/mesas">
                <i class="fas fa-times-circle"></i> Quitar filtro
            </a>
        </div>
    </c:if>

    <div class="toolbar">
        <div class="search-input">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por zona, mesa…">
        </div>
        <select id="filtroZonaSel" class="form-control" style="width:auto;padding:8px 12px;">
            <option value="">Todas las zonas</option>
            <c:forEach var="z" items="${zonas}">
                <option value="${z.nombreZona}" ${filtroZona.id == z.id ? 'selected' : ''}>
                    ${z.nombreZona}
                </option>
            </c:forEach>
        </select>
    </div>

    <div class="table-card">
        <div class="table-responsive">
            <table id="tablaMesas">
                <thead>
                    <tr>
                        <th>Mesa N.°</th>
                        <th>Zona / Puesto</th>
                        <th>Capacidad</th>
                        <th>Ciudadanos Inscritos</th>
                        <th class="col-acciones">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <c:choose>
                        <c:when test="${empty mesas}">
                            <tr>
                                <td colspan="5">
                                    <div class="empty-state">
                                        <i class="fas fa-table"></i>
                                        <p>No hay mesas de votación registradas.</p>
                                    </div>
                                </td>
                            </tr>
                        </c:when>
                        <c:otherwise>
                            <c:forEach var="m" items="${mesas}">
                                <tr>
                                    <td><span class="num-mesa">${m.numeroMesa}</span></td>
                                    <td>
                                        <div class="zona-celda">
                                            <div class="zona-n">${m.nombreZona}</div>
                                            <div class="ciudad-n">
                                                <i class="fas fa-city" style="font-size:10px;margin-right:3px;"></i>
                                                ${m.ciudad}
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <strong>${m.capacidad}</strong> votantes
                                        <div class="capacidad-bar">
                                            <div class="bar-track">
                                                <%-- porcentaje de ocupación: (ciudadanos / capacidad) * 100 --%>
                                                <div class="bar-fill" style="width:${m.porcentajeOcupacion}%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span style="font-weight:600;">${m.ciudadanosInscritos}</span>
                                        <span style="color:var(--gris-400);font-size:12px;">
                                            / ${m.capacidad}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <button class="btn btn-secondary btn-sm btn-icon" title="Editar mesa"
                                                    onclick="abrirModalEditarMesa(${m.id}, ${m.idZona}, ${m.numeroMesa}, ${m.capacidad})">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-danger btn-sm btn-icon" title="Eliminar mesa"
                                                    onclick="confirmarEliminarMesa(${m.id}, ${m.numeroMesa}, '${m.nombreZona}')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</div>

<%-- ═══════════ MODAL CREAR / EDITAR MESA ═══════════ --%>
<div class="modal-overlay" id="modalMesa">
    <div class="modal" style="max-width:440px;">
        <div class="modal__header">
            <i class="fas fa-table" style="color:var(--azul-medio);"></i>
            <h3 id="modalMesaTitulo">Nueva Mesa de Votación</h3>
            <button class="modal-close" onclick="cerrarModal('modalMesa')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal__body">
            <form id="formMesa"
                  action="${pageContext.request.contextPath}/admin/mesas"
                  method="post" novalidate>
                <input type="hidden" name="id" id="mesaId">

                <div class="form-row">
                    <div class="form-group">
                        <label for="idZonaMesa">Zona de Votación <span class="req">*</span></label>
                        <select id="idZonaMesa" name="idZona" class="form-control" required>
                            <option value="">— Seleccione zona —</option>
                            <c:forEach var="z" items="${zonas}">
                                <option value="${z.id}">${z.nombreZona} — ${z.puestoVotacion}</option>
                            </c:forEach>
                        </select>
                    </div>
                </div>

                <div class="form-row cols-2">
                    <div class="form-group">
                        <label for="numeroMesa">Número de Mesa <span class="req">*</span></label>
                        <input type="number" id="numeroMesa" name="numeroMesa"
                               class="form-control" min="1" max="999" required>
                    </div>
                    <div class="form-group">
                        <label for="capacidadMesa">Capacidad <span class="req">*</span></label>
                        <input type="number" id="capacidadMesa" name="capacidad"
                               class="form-control" min="1" max="500" value="200" required>
                        <p style="font-size:11px;color:var(--gris-600);margin-top:4px;">Máx. votantes habilitados</p>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal__footer">
            <button class="btn btn-secondary" onclick="cerrarModal('modalMesa')">Cancelar</button>
            <button class="btn btn-primary" onclick="submitFormMesa()">
                <i class="fas fa-save"></i> <span id="btnMesaLabel">Guardar</span>
            </button>
        </div>
    </div>
</div>

<%-- ═══════════ FORMULARIO OCULTO PARA ELIMINAR (MÉTODO POST) ═══════════ --%>
<form id="formEliminar" action="${pageContext.request.contextPath}/admin/mesas" method="post" style="display:none;">
    <input type="hidden" name="action" value="eliminar">
    <input type="hidden" name="id" id="inputEliminarId">
</form>

<%-- ═══════════ CONFIRM ELIMINAR ═══════════ --%>
<div class="confirm-overlay" id="confirmEliminar">
    <div class="confirm-box">
        <div class="confirm-icon"><i class="fas fa-trash-alt"></i></div>
        <h3>¿Eliminar mesa?</h3>
        <p id="confirmMesaMsg">Solo se puede eliminar si no hay ciudadanos inscritos en ella.</p>
        <div class="confirm-actions">
            <button class="btn btn-secondary" onclick="cerrarConfirm()">Cancelar</button>
            <button class="btn btn-danger" id="btnConfirmEliminar" type="button">
                <i class="fas fa-trash"></i> Eliminar
            </button>
        </div>
    </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script>
    // CORRECCIÓN PRINCIPAL: Obtener contextPath de forma segura
    const CTX = '<%= request.getContextPath()%>';

    function abrirModal(id) {
        document.getElementById(id).classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function cerrarModal(id) {
        document.getElementById(id).classList.remove('active');
        document.body.style.overflow = '';
    }
    document.querySelectorAll('.modal-overlay,.confirm-overlay').forEach(o => {
        o.addEventListener('click', e => {
            if (e.target === o)
                cerrarModal(o.id);
        });
    });

    function abrirModalCrearMesa() {
        document.getElementById('modalMesaTitulo').textContent = 'Nueva Mesa de Votación';
        document.getElementById('btnMesaLabel').textContent = 'Guardar';
        document.getElementById('formMesa').reset();
        document.getElementById('mesaId').value = '';
        document.getElementById('capacidadMesa').value = 200;
        // Pre-seleccionar zona si hay filtro activo
        const filtroZona = '${filtroZona.id}';
        if (filtroZona)
            document.getElementById('idZonaMesa').value = filtroZona;
        abrirModal('modalMesa');
    }

    function abrirModalEditarMesa(id, idZona, numero, capacidad) {
        document.getElementById('modalMesaTitulo').textContent = 'Editar Mesa de Votación';
        document.getElementById('btnMesaLabel').textContent = 'Actualizar';
        document.getElementById('mesaId').value = id;
        document.getElementById('idZonaMesa').value = idZona;
        document.getElementById('numeroMesa').value = numero;
        document.getElementById('capacidadMesa').value = capacidad;
        abrirModal('modalMesa');
    }

    function submitFormMesa() {
        const form = document.getElementById('formMesa');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        form.submit();
    }

    function confirmarEliminarMesa(id, numero, zona) {
        document.getElementById('confirmMesaMsg').innerHTML =
                `¿Eliminar la <strong>Mesa ${numero}</strong> de ${zona}?<br>
       Solo si no hay ciudadanos inscritos en ella.`;
        document.getElementById('inputEliminarId').value = id;

        // Configurar el botón para que envíe el formulario POST
        const btnEliminar = document.getElementById('btnConfirmEliminar');
        btnEliminar.onclick = function () {
            document.getElementById('formEliminar').submit();
        };

        document.getElementById('confirmEliminar').classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function cerrarConfirm() {
        document.getElementById('confirmEliminar').classList.remove('active');
        document.body.style.overflow = '';
    }

    document.getElementById('searchInput').addEventListener('input', filtrar);
    document.getElementById('filtroZonaSel').addEventListener('change', filtrar);
    function filtrar() {
        const q = document.getElementById('searchInput').value.toLowerCase();
        const z = document.getElementById('filtroZonaSel').value.toLowerCase();
        document.querySelectorAll('#tablaMesas tbody tr').forEach(row => {
            const t = row.textContent.toLowerCase();
            row.style.display = (t.includes(q) && (z === '' || t.includes(z))) ? '' : 'none';
        });
    }

    const flash = document.getElementById('flashToast');
    if (flash)
        setTimeout(() => flash.remove(), 4500);
</script>
</body>
</html>