<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Acceso Administrativo — Registraduría de Nobsa</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,600;8..60,700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <style>
            :root {
                --azul-oscuro:#003366;
                --azul-medio:#1A5EA8;
                --azul-vivo:#2563EB;
                --azul-claro:#EBF2FC;
                --blanco:#FFFFFF;
                --gris-100:#F4F6F9;
                --gris-200:#EAECEF;
                --gris-300:#CED4DA;
                --gris-600:#5A6470;
                --gris-700:#3E4752;
                --negro:#111318;
                --rojo:#C0392B;
                --rojo-claro:#FDEDEC;
                --font-display:'Source Serif 4',Georgia,serif;
                --font-body:'IBM Plex Sans',sans-serif;
            }
            *,*::before,*::after{
                box-sizing:border-box;
                margin:0;
                padding:0;
            }
            body{
                font-family:var(--font-body);
                background:var(--gris-100);
                min-height:100vh;
                display:flex;
                align-items:center;
                justify-content:center;
                padding:24px;
            }
            .login-wrap{
                width:100%;
                max-width:420px;
            }
            .brand-header{
                text-align:center;
                margin-bottom:28px;
            }
            .brand-icon{
                width:56px;
                height:56px;
                background:var(--azul-oscuro);
                border-radius:14px;
                display:inline-flex;
                align-items:center;
                justify-content:center;
                margin-bottom:12px;
            }
            .brand-icon i{
                color:var(--blanco);
                font-size:24px;
            }
            .brand-header h1{
                font-family:var(--font-display);
                font-size:20px;
                color:var(--azul-oscuro);
                font-weight:700;
                line-height:1.3;
            }
            .brand-header p{
                font-size:13px;
                color:var(--gris-600);
                margin-top:4px;
            }
            .card{
                background:var(--blanco);
                border-radius:12px;
                box-shadow:0 4px 24px rgba(0,0,0,.10);
                padding:32px;
            }
            .card h2{
                font-size:16px;
                font-weight:600;
                color:var(--negro);
                margin-bottom:22px;
                padding-bottom:14px;
                border-bottom:1px solid var(--gris-200);
            }
            .field{
                margin-bottom:16px;
            }
            .field label{
                display:block;
                font-size:12px;
                font-weight:600;
                color:var(--gris-700);
                text-transform:uppercase;
                letter-spacing:.5px;
                margin-bottom:6px;
            }
            .input-wrap{
                position:relative;
            }
            .input-wrap i{
                position:absolute;
                left:12px;
                top:50%;
                transform:translateY(-50%);
                color:var(--gris-600);
                font-size:14px;
            }
            .input-wrap input{
                width:100%;
                padding:10px 12px 10px 36px;
                border:1px solid var(--gris-300);
                border-radius:6px;
                font-family:var(--font-body);
                font-size:14px;
                color:var(--negro);
            }
            .input-wrap input:focus{
                outline:none;
                border-color:var(--azul-vivo);
                box-shadow:0 0 0 3px rgba(37,99,235,.12);
            }
            .alert-error{
                background:var(--rojo-claro);
                border:1px solid #f5c6cb;
                border-radius:6px;
                padding:10px 14px;
                font-size:13px;
                color:var(--rojo);
                display:flex;
                align-items:center;
                gap:8px;
                margin-bottom:16px;
            }
            .btn-login{
                width:100%;
                padding:11px;
                background:var(--azul-oscuro);
                color:var(--blanco);
                border:none;
                border-radius:6px;
                font-family:var(--font-body);
                font-size:15px;
                font-weight:600;
                cursor:pointer;
                transition:background .15s;
                display:flex;
                align-items:center;
                justify-content:center;
                gap:8px;
            }
            .btn-login:hover{
                background:var(--azul-medio);
            }
            .back-link{
                text-align:center;
                margin-top:18px;
                font-size:13px;
                color:var(--gris-600);
            }
            .back-link a{
                color:var(--azul-vivo);
                text-decoration:none;
            }
            .back-link a:hover{
                text-decoration:underline;
            }
        </style>
    </head>
    <body>
        <div class="login-wrap">
            <div class="brand-header">
                <div class="brand-icon"><i class="fas fa-landmark"></i></div>
                <h1>Registraduría Municipal<br>de Nobsa</h1>
                <p>Boyacá, Colombia</p>
            </div>
            <div class="card">
                <h2><i class="fas fa-lock" style="margin-right:6px;color:var(--azul-vivo)"></i>Acceso Administrativo</h2>
                <c:if test="${not empty errorLogin}">
                    <div class="alert-error">
                        <i class="fas fa-exclamation-circle"></i> ${errorLogin}
                    </div>
                </c:if>
                <form action="${pageContext.request.contextPath}/admin/login" method="post">
                    <div class="field">
                        <label>Usuario</label>
                        <div class="input-wrap">
                            <i class="fas fa-user"></i>
                            <input type="text" name="usuario" required autocomplete="username" placeholder="admin"/>
                        </div>
                    </div>
                    <div class="field">
                        <label>Contraseña</label>
                        <div class="input-wrap">
                            <i class="fas fa-key"></i>
                            <input type="password" name="contrasena" required autocomplete="current-password"/>
                        </div>
                    </div>
                    <button type="submit" class="btn-login">
                        <i class="fas fa-sign-in-alt"></i> Ingresar al Panel
                    </button>
                </form>
            </div>
            <div class="back-link">
                <a href="${pageContext.request.contextPath}/"><i class="fas fa-arrow-left"></i> Volver a consulta ciudadana</a>
            </div>
        </div>
    </body>
</html>