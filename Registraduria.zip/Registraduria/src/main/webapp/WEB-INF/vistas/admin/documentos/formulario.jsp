<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="pageTitle" value="Expedir Documento" scope="request"/>
<c:set var="activeSection" value="documentos" scope="request"/>

<%@ include file="/WEB-INF/vistas/admin/adminLayout.jsp" %>

<style>
    .form-card {
        background: var(--blanco);
        border-radius: 10px;
        box-shadow: var(--shadow-md);
        max-width: 700px;
        margin: 0 auto;
        overflow: hidden;
    }
    .form-card__header {
        padding: 22px 28px;
        border-bottom: 1px solid var(--gris-200);
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .form-card__header .icon {
        width: 38px;
        height: 38px;
        background: var(--verde-claro);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .form-card__header .icon i {
        color: var(--verde);
        font-size: 16px;
    }
    .form-card__header h2 {
        font-family: var(--font-display);
        font-size: 18px;
        color: var(--azul-oscuro);
        font-weight: 700;
    }
    .form-card__body {
        padding: 28px 28px 10px;
    }
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-bottom: 16px;
    }
    .form-row.single {
        grid-template-columns: 1fr;
    }
    .form-row.triple {
        grid-template-columns: 1fr 1fr 1fr;
    }
    .field label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--gris-700);
        text-transform: uppercase;
        letter-spacing: .5px;
        margin-bottom: 6px;
    }
    .field label span.req {
        color: var(--rojo);
        margin-left: 2px;
    }
    .field input, .field select, .field textarea {
        width: 100%;
        padding: 9px 12px;
        border: 1px solid var(--gris-300);
        border-radius: 6px;
        font-family: var(--font-body);
        font-size: 14px;
        color: var(--negro);
        background: var(--blanco);
        transition: border-color .15s;
    }
    .field input:focus, .field select:focus, .field textarea:focus {
        outline: none;
        border-color: var(--azul-vivo);
        box-shadow: 0 0 0 3px rgba(37,99,235,.12);
    }
    .field textarea {
        resize: vertical;
        min-height: 70px;
    }
    .citizen-info {
        background: var(--azul-claro);
        border-radius: 8px;
        padding: 12px 16px;
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
    }
    .citizen-info i {
        color: var(--azul-vivo);
        font-size: 18px;
    }
    .citizen-info p {
        font-size: 14px;
        color: var(--azul-oscuro);
        font-weight: 500;
    }
    .citizen-info span {
        font-size: 12px;
        color: var(--azul-medio);
        display: block;
        margin-top: 2px;
    }
    .form-card__footer {
        padding: 18px 28px;
        border-top: 1px solid var(--gris-200);
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        background: var(--gris-100);
    }
    .btn {
        padding: 9px 20px;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        font-family: var(--font-body);
        display: inline-flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
    }
    .btn-secondary {
        background: var(--blanco);
        color: var(--gris-700);
        border: 1px solid var(--gris-300);
    }
    .btn-secondary:hover {
        background: var(--gris-100);
    }
    .btn-primary {
        background: var(--azul-vivo);
        color: var(--blanco);
    }
    .btn-primary:hover {
        background: var(--azul-medio);
    }
</style>

<div class="main-content" style="padding: 28px;">
    <div class="form-card">
        <div class="form-card__header">
            <div class="icon"><i class="fas fa-file-alt"></i></div>
            <div>
                <h2>Expedir Nuevo Documento</h2>
                <p style="font-size:13px;color:var(--gris-600);margin-top:2px;">
                    Registre un documento oficial para un ciudadano de Nobsa.
                </p>
            </div>
        </div>

        <%-- ✅ CORREGIDO: acción con /admin/documentos + hidden action --%>
        <form action="${pageContext.request.contextPath}/admin/documentos" method="post">
            <input type="hidden" name="action" value="insertar">

            <div class="form-card__body">

                <%-- Selector de ciudadano --%>
                <div class="form-row single">
                    <div class="field">
                        <label>Ciudadano <span class="req">*</span></label>
                        <select name="id_ciudadano" required>
                            <option value="">— Seleccione un ciudadano —</option>
                            <c:forEach var="c" items="${ciudadanos}">
                                <option value="${c.id}">${c.apellidos}, ${c.nombres} — Doc: ${c.numeroDocumento}</option>
                            </c:forEach>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="field">
                        <label>Tipo de Documento <span class="req">*</span></label>
                        <select name="tipo_documento" required>
                            <option value="">— Seleccione —</option>
                            <option value="Cédula de Ciudadanía">Cédula de Ciudadanía</option>
                            <option value="Tarjeta de Identidad">Tarjeta de Identidad</option>
                            <option value="Registro Civil de Nacimiento">Registro Civil de Nacimiento</option>
                            <option value="Contraseña">Contraseña</option>
                        </select>
                    </div>
                    <div class="field">
                        <label>Número de Serie <span class="req">*</span></label>
                        <input type="text" name="numero_serie" maxlength="30" required
                               placeholder="Ej. CC-2024-00123"/>
                    </div>
                </div>

                <div class="form-row triple">
                    <div class="field">
                        <label>Fecha de Expedición <span class="req">*</span></label>
                        <input type="date" name="fecha_expedicion" required/>
                    </div>
                    <div class="field">
                        <label>Fecha de Vencimiento</label>
                        <input type="date" name="fecha_vencimiento"/>
                    </div>
                    <div class="field">
                        <label>Estado <span class="req">*</span></label>
                        <select name="estado" required>
                            <option value="vigente" selected>Vigente</option>
                            <option value="vencido">Vencido</option>
                            <option value="cancelado">Cancelado</option>
                        </select>
                    </div>
                </div>

                <div class="form-row single">
                    <div class="field">
                        <label>Observaciones</label>
                        <textarea name="observaciones" maxlength="300"
                                  placeholder="Notas del registrador (opcional)"></textarea>
                    </div>
                </div>

            </div>

            <div class="form-card__footer">
                <%-- ✅ CORREGIDO: enlace de cancelar con /admin/documentos --%>
                <a href="${pageContext.request.contextPath}/admin/documentos" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-stamp"></i> Expedir Documento
                </button>
            </div>
        </form>
    </div>
</div>
</body>
</html>