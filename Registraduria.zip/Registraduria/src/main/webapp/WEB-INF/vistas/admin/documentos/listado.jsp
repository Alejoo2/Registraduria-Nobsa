<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt"  prefix="fmt" %>

<c:set var="pageTitle" value="Documentos Expedidos" scope="request"/>
<c:set var="activeSection" value="documentos" scope="request"/>
<%@ include file="/WEB-INF/vistas/admin/adminLayout.jsp" %>

<style>
    .page-content {
        padding: 28px;
    }
    .page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
    }
    .page-header h2 {
        font-family: var(--font-display);
        font-size: 22px;
        font-weight: 700;
        color: var(--negro);
    }
    .page-header .page-subtitle {
        font-size: 13px;
        color: var(--gris-600);
        margin-top: 2px;
    }

    .filtro-activo {
        background: var(--azul-claro);
        border: 1px solid #BFDBFE;
        border-radius: 8px;
        padding: 10px 16px;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 16px;
        font-size: 13px;
        color: var(--azul-oscuro);
    }
    .filtro-activo i {
        color: var(--azul-medio);
    }
    .filtro-activo strong {
        font-weight: 600;
    }
    .filtro-activo a {
        margin-left: auto;
        color: var(--azul-medio);
        text-decoration: none;
        font-size: 12px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    .filtro-activo a:hover {
        text-decoration: underline;
    }

    .toolbar {
        background: var(--blanco);
        border-radius: 8px;
        border: 1px solid var(--gris-200);
        padding: 14px 20px;
        display: flex;
        align-items: center;
        gap: 14px;
        margin-bottom: 16px;
        box-shadow: var(--shadow-sm);
    }
    .search-input {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--gris-100);
        border: 1.5px solid var(--gris-200);
        border-radius: 6px;
        padding: 8px 14px;
        transition: border-color .15s;
    }
    .search-input:focus-within {
        border-color: var(--azul-vivo);
        background: var(--blanco);
    }
    .search-input i {
        color: var(--gris-400);
        font-size: 14px;
        flex-shrink: 0;
    }
    .search-input input {
        border: none;
        background: transparent;
        font-family: var(--font-body);
        font-size: 14px;
        color: var(--negro);
        width: 100%;
    }
    .search-input input:focus {
        outline: none;
    }
    .search-input input::placeholder {
        color: var(--gris-400);
    }

    .table-card {
        background: var(--blanco);
        border-radius: 8px;
        border: 1px solid var(--gris-200);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }
    .table-responsive {
        overflow-x: auto;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    thead tr {
        background: var(--gris-100);
        border-bottom: 2px solid var(--gris-200);
    }
    thead th {
        padding: 11px 16px;
        font-size: 11.5px;
        font-weight: 700;
        letter-spacing: .8px;
        text-transform: uppercase;
        color: var(--gris-600);
        text-align: left;
        white-space: nowrap;
    }
    thead th.col-acciones {
        text-align: right;
    }
    tbody tr {
        border-bottom: 1px solid var(--gris-200);
        transition: background .12s;
    }
    tbody tr:last-child {
        border-bottom: none;
    }
    tbody tr:hover {
        background: var(--azul-claro);
    }
    tbody td {
        padding: 11px 16px;
        font-size: 14px;
        vertical-align: middle;
    }
    .serie-num {
        font-family: monospace;
        font-size: 13px;
        background: var(--gris-100);
        padding: 2px 8px;
        border-radius: 4px;
        color: var(--gris-800);
    }
    .ciudadano-celda .nombre-doc {
        font-weight: 600;
        font-size: 14px;
    }
    .ciudadano-celda .cedula-doc {
        font-size: 12px;
        color: var(--gris-600);
    }
    .actions {
        display: flex;
        justify-content: flex-end;
        gap: 6px;
    }
    .empty-state {
        text-align: center;
        padding: 48px 24px;
        color: var(--gris-600);
    }
    .empty-state i {
        font-size: 36px;
        color: var(--gris-300);
        margin-bottom: 12px;
        display: block;
    }
    .pagination-bar {
        padding: 14px 20px;
        border-top: 1px solid var(--gris-200);
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: var(--gris-100);
    }
    .pagination-bar .info {
        font-size: 12.5px;
        color: var(--gris-600);
    }

    /* Badges de estado */
    .badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 600;
    }
    .badge-vigente {
        background: #DCFCE7;
        color: #166534;
    }
    .badge-vencido {
        background: #FEE2E2;
        color: #991B1B;
    }
    .badge-cancelado {
        background: #F3F4F6;
        color: #374151;
    }
</style>
<div class="page-content">
    <div class="page-header">
        <div>
            <h2>
                <i class="fas fa-id-card" style="color:var(--azul-medio);margin-right:10px;font-size:20px;"></i>
                Documentos Expedidos
            </h2>
            <p class="page-subtitle">Registro de cédulas, tarjetas de identidad, registros civiles y contraseñas</p>
        </div>
        <button class="btn btn-primary" onclick="abrirModalExpedir()">
            <i class="fas fa-plus"></i> Expedir Documento
        </button>
    </div>

    <%-- MENSAJES FLASH --%>
    <c:if test="${not empty successMsg}">
        <div class="toast toast-success" id="flashToast" style="position:relative;margin-bottom:16px;animation:none;">
            <i class="fas fa-check-circle"></i>
            <span class="toast-msg">${successMsg}</span>
            <button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
        </div>
    </c:if>
    <c:if test="${not empty errorMsg}">
        <div class="toast toast-error" id="flashToast" style="position:relative;margin-bottom:16px;animation:none;">
            <i class="fas fa-exclamation-circle"></i>
            <span class="toast-msg">${errorMsg}</span>
            <button class="toast-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
        </div>
    </c:if>

    <%-- FILTRO ACTIVO --%>
    <c:if test="${not empty filtroCiudadano}">
        <div class="filtro-activo">
            <i class="fas fa-filter"></i>
            Mostrando documentos de:
            <strong>${filtroCiudadano.nombres} ${filtroCiudadano.apellidos}</strong>
            (C.C. ${filtroCiudadano.numeroDocumento})
            <a href="${pageContext.request.contextPath}/admin/documentos">
                <i class="fas fa-times-circle"></i> Quitar filtro
            </a>
        </div>
    </c:if>

    <%-- TOOLBAR --%>
    <div class="toolbar">
        <div class="search-input">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por ciudadano, serie, tipo de documento…">
        </div>
        <select id="filtroEstado" class="form-control" style="width:auto;padding:8px 12px;">
            <option value="">Todos los estados</option>
            <option value="vigente">Vigente</option>
            <option value="vencido">Vencido</option>
            <option value="cancelado">Cancelado</option>
        </select>
    </div>

    <%-- TABLA --%>
    <div class="table-card">
        <div class="table-responsive">
            <table id="tablaDocumentos">
                <thead>
                    <tr>
                        <th>N.° Serie</th>
                        <th>Ciudadano</th>
                        <th>Tipo de Documento</th>
                        <th>Fecha Expedición</th>
                        <th>Vencimiento</th>
                        <th>Estado</th>
                        <th class="col-acciones">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <c:choose>
                        <c:when test="${empty documentos}">
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <i class="fas fa-id-card"></i>
                                        <p>No hay documentos registrados.</p>
                                    </div>
                                </td>
                            </tr>
                        </c:when>
                        <c:otherwise>
                            <c:forEach var="d" items="${documentos}">
                                <tr>
                                    <td><span class="serie-num">${d.numeroSerie}</span></td>
                                    <td>
                                        <div class="ciudadano-celda">
                                            <%-- ✅ CORREGIDO: numeroDocumentoCiudadano (coincide con el modelo) --%>
                                            <div class="nombre-doc">${d.nombreCiudadano}</div>
                                            <div class="cedula-doc">C.C. ${d.numeroDocumentoCiudadano}</div>
                                        </div>
                                    </td>
                                    <td>${d.tipoDocumento}</td>
                                    <td>
                                        <%-- ✅ CORREGIDO: Formato para LocalDate --%>
                                        ${d.fechaExpedicion}
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty d.fechaVencimiento}">
                                                ${d.fechaVencimiento}
                                            </c:when>
                                            <c:otherwise>
                                                <span style="color:var(--gris-400);">Sin vencimiento</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${d.estado == 'vigente'}">
                                                <span class="badge badge-vigente"><i class="fas fa-check-circle"></i> Vigente</span>
                                            </c:when>
                                            <c:when test="${d.estado == 'vencido'}">
                                                <span class="badge badge-vencido"><i class="fas fa-times-circle"></i> Vencido</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge badge-cancelado"><i class="fas fa-ban"></i> Cancelado</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <button class="btn btn-secondary btn-sm"
                                                    title="Cambiar estado"
                                                    onclick="confirmarCambioEstado(${d.id}, '${d.estado}', '${d.numeroSerie}')">
                                                <i class="fas fa-sync-alt"></i> Estado
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>
        <div class="pagination-bar">
            <span class="info" id="totalCount">${fn:length(documentos)} documento(s)</span>
        </div>
    </div>
</div>

<%-- MODAL: EXPEDIR DOCUMENTO --%>
<div class="modal-overlay" id="modalDocumento">
    <div class="modal">
        <div class="modal__header">
            <i class="fas fa-file-alt" style="color:var(--azul-medio);"></i>
            <h3>Expedir Documento</h3>
            <button class="modal-close" onclick="cerrarModal('modalDocumento')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal__body">
            <form id="formDocumento"
                  action="${pageContext.request.contextPath}/admin/documentos"
                  method="post" novalidate>
                <input type="hidden" name="action" value="insertar">

                <div class="form-row">
                    <div class="form-group">
                        <label for="idCiudadano">Ciudadano <span class="req">*</span></label>
                        <select id="idCiudadano" name="idCiudadano" class="form-control" required>
                            <option value="">— Seleccione un ciudadano —</option>
                            <c:forEach var="c" items="${ciudadanos}">
                                <option value="${c.id}" ${filtroCiudadano != null && filtroCiudadano.id == c.id ? 'selected' : ''}>
                                    ${c.nombres} ${c.apellidos} — C.C. ${c.numeroDocumento}
                                </option>
                            </c:forEach>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="tipoDocumento">Tipo de Documento <span class="req">*</span></label>
                        <select id="tipoDocumento" name="tipoDocumento" class="form-control" required>
                            <option value="">— Seleccione —</option>
                            <option value="Cédula de Ciudadanía">Cédula de Ciudadanía</option>
                            <option value="Tarjeta de Identidad">Tarjeta de Identidad</option>
                            <option value="Registro Civil de Nacimiento">Registro Civil de Nacimiento</option>
                            <option value="Contraseña">Contraseña</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="numeroSerie">Número de Serie <span class="req">*</span></label>
                        <input type="text" id="numeroSerie" name="numeroSerie"
                               class="form-control" maxlength="30"
                               placeholder="Ej: CC-2025-00789" required>
                    </div>
                </div>

                <div class="form-row cols-2">
                    <div class="form-group">
                        <label for="fechaExpedicion">Fecha de Expedición <span class="req">*</span></label>
                        <input type="date" id="fechaExpedicion" name="fechaExpedicion"
                               class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="fechaVencimiento">Fecha de Vencimiento</label>
                        <input type="date" id="fechaVencimiento" name="fechaVencimiento"
                               class="form-control">
                        <p style="font-size:11px;color:var(--gris-600);margin-top:4px;">
                            Dejar vacío si no vence (ej. cédulas)
                        </p>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="observaciones">Observaciones del Registrador</label>
                        <textarea id="observaciones" name="observaciones"
                                  class="form-control" rows="2" maxlength="300"
                                  placeholder="Notas adicionales (opcional)…"
                                  style="resize:vertical;"></textarea>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal__footer">
            <button class="btn btn-secondary" onclick="cerrarModal('modalDocumento')">
                <i class="fas fa-times"></i> Cancelar
            </button>
            <button class="btn btn-primary" onclick="submitFormDocumento()">
                <i class="fas fa-file-export"></i> Expedir Documento
            </button>
        </div>
    </div>
</div>

<%-- MODAL: CAMBIAR ESTADO --%>
<div class="modal-overlay" id="modalEstado">
    <div class="modal" style="max-width:380px;">
        <div class="modal__header">
            <i class="fas fa-sync-alt" style="color:var(--azul-medio);"></i>
            <h3>Cambiar Estado del Documento</h3>
            <button class="modal-close" onclick="cerrarModal('modalEstado')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal__body">
            <p style="font-size:13.5px;color:var(--gris-600);margin-bottom:16px;">
                Documento: <strong id="estadoSerie"></strong>
            </p>
            <form id="formEstado"
                  action="${pageContext.request.contextPath}/admin/documentos"
                  method="post">
                <input type="hidden" name="action" value="cambiarEstado">
                <input type="hidden" name="id" id="estadoDocId">
                <div class="form-group">
                    <label for="nuevoEstado">Nuevo estado <span class="req">*</span></label>
                    <select id="nuevoEstado" name="estado" class="form-control" required>
                        <option value="vigente">✅ Vigente</option>
                        <option value="vencido">❌ Vencido</option>
                        <option value="cancelado">🚫 Cancelado</option>
                    </select>
                </div>
            </form>
        </div>
        <div class="modal__footer">
            <button class="btn btn-secondary" onclick="cerrarModal('modalEstado')">Cancelar</button>
            <button class="btn btn-primary" onclick="document.getElementById('formEstado').submit()">
                <i class="fas fa-save"></i> Actualizar Estado
            </button>
        </div>
    </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script>
    const CTX = '${pageContext.request.contextPath}';

    function abrirModal(id) {
        document.getElementById(id).classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function cerrarModal(id) {
        document.getElementById(id).classList.remove('active');
        document.body.style.overflow = '';
    }
    document.querySelectorAll('.modal-overlay').forEach(o => {
        o.addEventListener('click', e => {
            if (e.target === o)
                cerrarModal(o.id);
        });
    });

    function abrirModalExpedir() {
        document.getElementById('formDocumento').reset();
        const filtro = '${filtroCiudadano != null ? filtroCiudadano.id : ""}';
        if (filtro)
            document.getElementById('idCiudadano').value = filtro;
        abrirModal('modalDocumento');
    }

    function submitFormDocumento() {
        const form = document.getElementById('formDocumento');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        form.submit();
    }

    function confirmarCambioEstado(docId, estadoActual, serie) {
        document.getElementById('estadoDocId').value = docId;
        document.getElementById('estadoSerie').textContent = serie;
        document.getElementById('nuevoEstado').value = estadoActual;
        abrirModal('modalEstado');
    }

    // Búsqueda en tabla
    document.getElementById('searchInput').addEventListener('input', filtrarTabla);
    document.getElementById('filtroEstado').addEventListener('change', filtrarTabla);

    function filtrarTabla() {
        const q = document.getElementById('searchInput').value.toLowerCase();
        const est = document.getElementById('filtroEstado').value.toLowerCase();
        const rows = document.querySelectorAll('#tablaDocumentos tbody tr');
        let visible = 0;
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            const show = text.includes(q) && (est === '' || text.includes(est));
            row.style.display = show ? '' : 'none';
            if (show)
                visible++;
        });
        document.getElementById('totalCount').textContent = visible + ' documento(s)';
    }

    // Auto-dismiss flash
    const flash = document.getElementById('flashToast');
    if (flash)
        setTimeout(() => flash.remove(), 4500);

    // Pre-set fecha expedición a hoy
    const hoy = new Date().toISOString().split('T')[0];
    const fechaInput = document.getElementById('fechaExpedicion');
    if (fechaInput)
        fechaInput.value = hoy;
</script>
</body>
</html>