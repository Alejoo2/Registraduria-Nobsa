<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<c:set var="pageTitle" value="${empty ciudadano ? 'Nuevo Ciudadano' : 'Editar Ciudadano'}" scope="request"/>
<c:set var="activeSection" value="ciudadanos" scope="request"/>

<%@ include file="/WEB-INF/vistas/admin/adminLayout.jsp" %>

<style>
    .form-card {
        background: var(--blanco);
        border-radius: 10px;
        box-shadow: var(--shadow-md);
        max-width: 700px;
        margin: 0 auto;
        overflow: hidden;
    }
    .form-card__header {
        padding: 22px 28px;
        border-bottom: 1px solid var(--gris-200);
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .form-card__header .icon {
        width: 38px;
        height: 38px;
        background: var(--azul-claro);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .form-card__header .icon i {
        color: var(--azul-vivo);
        font-size: 16px;
    }
    .form-card__header h2 {
        font-family: var(--font-display);
        font-size: 18px;
        color: var(--azul-oscuro);
        font-weight: 700;
    }
    .form-card__body {
        padding: 28px 28px 10px;
    }
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-bottom: 16px;
    }
    .form-row.single {
        grid-template-columns: 1fr;
    }
    .field label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        color: var(--gris-700);
        text-transform: uppercase;
        letter-spacing: .5px;
        margin-bottom: 6px;
    }
    .field label span.req {
        color: var(--rojo);
        margin-left: 2px;
    }
    .field input, .field select {
        width: 100%;
        padding: 9px 12px;
        border: 1px solid var(--gris-300);
        border-radius: 6px;
        font-family: var(--font-body);
        font-size: 14px;
        color: var(--negro);
        background: var(--blanco);
        transition: border-color .15s;
    }
    .field input:focus, .field select:focus {
        outline: none;
        border-color: var(--azul-vivo);
        box-shadow: 0 0 0 3px rgba(37,99,235,.12);
    }
    .field input[readonly] {
        background: var(--gris-100);
        color: var(--gris-600);
        cursor: not-allowed;
    }
    .form-card__footer {
        padding: 18px 28px;
        border-top: 1px solid var(--gris-200);
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        background: var(--gris-100);
    }
    .btn {
        padding: 9px 20px;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        font-family: var(--font-body);
        display: inline-flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
    }
    .btn-secondary {
        background: var(--blanco);
        color: var(--gris-700);
        border: 1px solid var(--gris-300);
    }
    .btn-secondary:hover {
        background: var(--gris-100);
    }
    .btn-primary {
        background: var(--azul-vivo);
        color: var(--blanco);
    }
    .btn-primary:hover {
        background: var(--azul-medio);
    }
</style>

<div class="main-content" style="padding: 28px;">
    <div class="form-card">
        <div class="form-card__header">
            <div class="icon"><i class="fas fa-user-plus"></i></div>
            <div>
                <h2>${empty ciudadano ? 'Registrar Nuevo Ciudadano' : 'Editar Ciudadano'}</h2>
                <p style="font-size:13px;color:var(--gris-600);margin-top:2px;">
                    ${empty ciudadano ? 'Complete todos los campos obligatorios.' : 'Modifique los datos del ciudadano. El número de documento no puede cambiarse.'}
                </p>
            </div>
        </div>

        <form action="${pageContext.request.contextPath}/ciudadanos" method="post">
            <input type="hidden" name="id" value="${ciudadano.id}"/>

            <div class="form-card__body">
                <div class="form-row">
                    <div class="field">
                        <label>Número de Documento <span class="req">*</span></label>
                        <input type="text" name="numero_documento" maxlength="20"
                               value="${ciudadano.numeroDocumento}"
                               ${not empty ciudadano ? 'readonly' : 'required'}
                               placeholder="Ej. 1052345678"/>
                    </div>
                    <div class="field">
                        <label>Fecha de Nacimiento <span class="req">*</span></label>
                        <input type="date" name="fecha_nacimiento"
                               value="${fechaNacimientoFmt}" required/>
                    </div>
                </div>

                <div class="form-row">
                    <div class="field">
                        <label>Nombres <span class="req">*</span></label>
                        <input type="text" name="nombres" maxlength="80"
                               value="${ciudadano.nombres}" required placeholder="Nombres completos"/>
                    </div>
                    <div class="field">
                        <label>Apellidos <span class="req">*</span></label>
                        <input type="text" name="apellidos" maxlength="80"
                               value="${ciudadano.apellidos}" required placeholder="Apellidos completos"/>
                    </div>
                </div>

                <div class="form-row">
                    <div class="field">
                        <label>Vereda / Barrio <span class="req">*</span></label>
                        <input type="text" name="vereda_barrio" maxlength="80"
                               value="${ciudadano.veredaBarrio}" required placeholder="Ej. Centro, La Heroica"/>
                    </div>
                    <div class="field">
                        <label>Teléfono</label>
                        <input type="tel" name="telefono" maxlength="20"
                               value="${ciudadano.telefono}" placeholder="Ej. 3101234567"/>
                    </div>
                </div>

                <div class="form-row single">
                    <div class="field">
                        <label>Correo Electrónico</label>
                        <input type="email" name="correo" maxlength="100"
                               value="${ciudadano.correo}" placeholder="correo@ejemplo.com"/>
                    </div>
                </div>
            </div>

            <div class="form-card__footer">
                <a href="${pageContext.request.contextPath}/ciudadanos" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    ${empty ciudadano ? 'Registrar Ciudadano' : 'Guardar Cambios'}
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
