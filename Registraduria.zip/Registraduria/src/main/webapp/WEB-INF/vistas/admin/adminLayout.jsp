<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${pageTitle} — Panel Administrativo · Registraduría Nobsa</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,600;8..60,700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <style>
            :root {
                --azul-oscuro: #003366;
                --azul-medio: #1A5EA8;
                --azul-vivo: #2563EB;
                --azul-claro: #EBF2FC;
                --dorado: #B8860B;
                --dorado-claro: #FDF6E3;
                --blanco: #FFFFFF;
                --gris-100: #F4F6F9;
                --gris-200: #EAECEF;
                --gris-300: #CED4DA;
                --gris-400: #9DA7B0;
                --gris-600: #5A6470;
                --gris-700: #3E4752;
                --gris-800: #2C333A;
                --negro: #111318;
                --verde: #177244;
                --verde-claro: #E8F5EE;
                --rojo: #C0392B;
                --rojo-claro: #FDEDEC;
                --amarillo: #B7791F;
                --amarillo-claro: #FFFBEB;
                --sidebar-w: 240px;
                --topbar-h: 58px;
                --font-display: 'Source Serif 4', Georgia, serif;
                --font-body: 'IBM Plex Sans', sans-serif;
                --shadow-sm: 0 1px 3px rgba(0,0,0,.08);
                --shadow-md: 0 4px 12px rgba(0,0,0,.10), 0 2px 4px rgba(0,0,0,.06);
                --shadow-lg: 0 10px 30px rgba(0,0,0,.14);
                --shadow-modal: 0 20px 60px rgba(0,0,0,.22);
            }
            *, *::before, *::after {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            html {
                font-size: 15px;
            }
            body {
                font-family: var(--font-body);
                background: var(--gris-100);
                color: var(--negro);
                min-height: 100vh;
                display: flex;
                -webkit-font-smoothing: antialiased;
            }

            /* ══ SIDEBAR ══ */
            .sidebar {
                width: var(--sidebar-w);
                background: var(--azul-oscuro);
                min-height: 100vh;
                display: flex;
                flex-direction: column;
                flex-shrink: 0;
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                z-index: 100;
                transition: transform .25s ease;
            }
            .sidebar__brand {
                padding: 20px 20px 18px;
                border-bottom: 1px solid rgba(255,255,255,.1);
            }
            .sidebar__brand .logo-row {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-bottom: 8px;
            }
            .sidebar__brand .logo-icon {
                width: 34px;
                height: 34px;
                background: rgba(255,255,255,.15);
                border-radius: 6px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .sidebar__brand .logo-icon i {
                color: var(--blanco);
                font-size: 16px;
            }
            .sidebar__brand h2 {
                font-family: var(--font-display);
                font-size: 14px;
                font-weight: 700;
                color: var(--blanco);
                line-height: 1.3;
            }
            .sidebar__brand p {
                font-size: 11px;
                color: rgba(255,255,255,.5);
                letter-spacing: .3px;
            }

            .sidebar__nav {
                flex: 1;
                padding: 20px 12px;
            }
            .sidebar__nav .nav-label {
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 1.5px;
                text-transform: uppercase;
                color: rgba(255,255,255,.35);
                padding: 0 8px;
                margin-bottom: 8px;
                margin-top: 20px;
            }
            .sidebar__nav .nav-label:first-child {
                margin-top: 0;
            }

            .nav-item {
                display: flex;
                align-items: center;
                gap: 11px;
                padding: 9px 12px;
                border-radius: 6px;
                text-decoration: none;
                color: rgba(255,255,255,.72);
                font-size: 13.5px;
                font-weight: 400;
                transition: background .15s, color .15s;
                margin-bottom: 2px;
            }
            .nav-item i {
                width: 16px;
                text-align: center;
                font-size: 14px;
            }
            .nav-item:hover {
                background: rgba(255,255,255,.08);
                color: var(--blanco);
            }
            .nav-item.active {
                background: rgba(255,255,255,.15);
                color: var(--blanco);
                font-weight: 600;
            }
            .nav-item.active i {
                color: #93C5FD;
            }

            .sidebar__footer {
                padding: 16px 12px;
                border-top: 1px solid rgba(255,255,255,.1);
            }
            .sidebar__footer .user-row {
                display: flex;
                align-items: center;
                gap: 10px;
                padding: 8px 12px;
                border-radius: 6px;
            }
            .sidebar__footer .user-avatar {
                width: 30px;
                height: 30px;
                border-radius: 50%;
                background: rgba(255,255,255,.2);
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .sidebar__footer .user-avatar i {
                color: var(--blanco);
                font-size: 13px;
            }
            .sidebar__footer .user-name {
                font-size: 13px;
                font-weight: 500;
                color: var(--blanco);
            }
            .sidebar__footer .user-role {
                font-size: 11px;
                color: rgba(255,255,255,.5);
            }
            .sidebar__footer .btn-logout {
                display: flex;
                align-items: center;
                gap: 8px;
                width: 100%;
                padding: 9px 12px;
                margin-top: 6px;
                background: rgba(255,255,255,.06);
                border: 1px solid rgba(255,255,255,.12);
                border-radius: 6px;
                color: rgba(255,255,255,.6);
                font-family: var(--font-body);
                font-size: 13px;
                cursor: pointer;
                text-decoration: none;
                transition: all .15s;
            }
            .sidebar__footer .btn-logout:hover {
                background: rgba(255,255,255,.12);
                color: var(--blanco);
            }

            /* ══ ÁREA PRINCIPAL ══ */
            .main-area {
                margin-left: var(--sidebar-w);
                flex: 1;
                display: flex;
                flex-direction: column;
                min-height: 100vh;
            }

            /* ── TOPBAR ── */
            .topbar {
                height: var(--topbar-h);
                background: var(--blanco);
                border-bottom: 1px solid var(--gris-200);
                display: flex;
                align-items: center;
                padding: 0 28px;
                gap: 16px;
                box-shadow: var(--shadow-sm);
                position: sticky;
                top: 0;
                z-index: 50;
            }
            .topbar .breadcrumb {
                display: flex;
                align-items: center;
                gap: 6px;
                font-size: 13px;
                color: var(--gris-600);
            }
            .topbar .breadcrumb a {
                color: var(--azul-medio);
                text-decoration: none;
            }
            .topbar .breadcrumb a:hover {
                text-decoration: underline;
            }
            .topbar .breadcrumb i {
                font-size: 10px;
                color: var(--gris-400);
            }
            .topbar .breadcrumb .current {
                font-weight: 600;
                color: var(--negro);
            }
            .topbar-right {
                margin-left: auto;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .topbar-right .btn-public {
                font-size: 12px;
                font-weight: 500;
                color: var(--azul-medio);
                text-decoration: none;
                padding: 5px 12px;
                border: 1px solid var(--azul-claro);
                background: var(--azul-claro);
                border-radius: 4px;
                transition: all .15s;
                display: flex;
                align-items: center;
                gap: 6px;
            }
            .topbar-right .btn-public:hover {
                background: var(--azul-medio);
                color: var(--blanco);
            }

            /* ── TOAST NOTIFICATIONS ── */
            .toast-container {
                position: fixed;
                bottom: 24px;
                right: 24px;
                z-index: 9999;
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .toast {
                min-width: 280px;
                max-width: 380px;
                background: var(--blanco);
                border-radius: 8px;
                box-shadow: var(--shadow-lg);
                padding: 14px 16px;
                display: flex;
                align-items: flex-start;
                gap: 12px;
                animation: toastIn .3s ease both;
            }
            .toast.toast-success {
                border-left: 4px solid var(--verde);
            }
            .toast.toast-error   {
                border-left: 4px solid var(--rojo);
            }
            .toast.toast-warning {
                border-left: 4px solid var(--amarillo);
            }
            .toast i {
                font-size: 16px;
                margin-top: 1px;
                flex-shrink: 0;
            }
            .toast.toast-success i {
                color: var(--verde);
            }
            .toast.toast-error   i {
                color: var(--rojo);
            }
            .toast.toast-warning i {
                color: var(--amarillo);
            }
            .toast .toast-msg {
                font-size: 13.5px;
                font-weight: 500;
                color: var(--gris-800);
            }
            .toast .toast-close {
                margin-left: auto;
                background: none;
                border: none;
                cursor: pointer;
                color: var(--gris-400);
                font-size: 14px;
                padding: 0;
                flex-shrink: 0;
                align-self: center;
            }
            .toast .toast-close:hover {
                color: var(--gris-800);
            }

            /* ── MODAL BASE ── */
            .modal-overlay {
                display: none;
                position: fixed;
                inset: 0;
                z-index: 1000;
                background: rgba(0,0,0,.45);
                align-items: center;
                justify-content: center;
                padding: 20px;
                animation: fadeOverlay .2s ease;
            }
            .modal-overlay.active {
                display: flex;
            }
            .modal {
                background: var(--blanco);
                border-radius: 10px;
                box-shadow: var(--shadow-modal);
                width: 100%;
                max-width: 520px;
                max-height: 90vh;
                overflow-y: auto;
                animation: modalIn .25s ease both;
            }
            .modal__header {
                padding: 20px 24px 18px;
                border-bottom: 1px solid var(--gris-200);
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .modal__header h3 {
                font-size: 17px;
                font-weight: 600;
                color: var(--negro);
            }
            .modal__header .modal-close {
                margin-left: auto;
                background: none;
                border: none;
                color: var(--gris-400);
                font-size: 18px;
                cursor: pointer;
                padding: 4px;
                border-radius: 4px;
                line-height: 1;
                transition: all .15s;
            }
            .modal__header .modal-close:hover {
                background: var(--gris-200);
                color: var(--gris-800);
            }
            .modal__body {
                padding: 24px;
            }
            .modal__footer {
                padding: 16px 24px;
                border-top: 1px solid var(--gris-200);
                display: flex;
                justify-content: flex-end;
                gap: 10px;
            }

            /* ── CONFIRM DIALOG ── */
            .confirm-overlay {
                display: none;
                position: fixed;
                inset: 0;
                z-index: 2000;
                background: rgba(0,0,0,.5);
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            .confirm-overlay.active {
                display: flex;
            }
            .confirm-box {
                background: var(--blanco);
                border-radius: 10px;
                box-shadow: var(--shadow-modal);
                padding: 28px;
                max-width: 360px;
                width: 100%;
                text-align: center;
                animation: modalIn .2s ease both;
            }
            .confirm-box .confirm-icon {
                width: 56px;
                height: 56px;
                border-radius: 50%;
                background: var(--rojo-claro);
                display: inline-flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 16px;
            }
            .confirm-box .confirm-icon i {
                color: var(--rojo);
                font-size: 22px;
            }
            .confirm-box h3 {
                font-size: 17px;
                font-weight: 600;
                margin-bottom: 8px;
            }
            .confirm-box p {
                font-size: 14px;
                color: var(--gris-600);
                line-height: 1.6;
                margin-bottom: 24px;
            }
            .confirm-box .confirm-actions {
                display: flex;
                gap: 10px;
                justify-content: center;
            }

            /* ── FORM ELEMENTS COMUNES ── */
            .form-row {
                display: grid;
                gap: 16px;
                margin-bottom: 16px;
            }
            .form-row.cols-2 {
                grid-template-columns: 1fr 1fr;
            }
            .form-row.cols-3 {
                grid-template-columns: 1fr 1fr 1fr;
            }
            .form-group {
            }
            .form-group label {
                display: block;
                font-size: 12.5px;
                font-weight: 600;
                color: var(--gris-800);
                margin-bottom: 6px;
                letter-spacing: .2px;
            }
            .form-group label .req {
                color: var(--rojo);
                margin-left: 2px;
            }
            .form-control {
                width: 100%;
                padding: 9px 12px;
                border: 1.5px solid var(--gris-300);
                border-radius: 6px;
                font-family: var(--font-body);
                font-size: 14px;
                color: var(--negro);
                background: var(--blanco);
                transition: border-color .15s, box-shadow .15s;
            }
            .form-control:focus {
                outline: none;
                border-color: var(--azul-vivo);
                box-shadow: 0 0 0 3px rgba(37,99,235,.1);
            }
            .form-control.is-invalid {
                border-color: var(--rojo);
            }
            .invalid-feedback {
                font-size: 12px;
                color: var(--rojo);
                margin-top: 4px;
            }
            select.form-control {
                cursor: pointer;
            }

            /* ── BOTONES ── */
            .btn {
                display: inline-flex;
                align-items: center;
                gap: 7px;
                padding: 9px 18px;
                border-radius: 6px;
                font-family: var(--font-body);
                font-size: 13.5px;
                font-weight: 500;
                cursor: pointer;
                border: none;
                text-decoration: none;
                transition: all .15s ease;
                white-space: nowrap;
            }
            .btn i {
                font-size: 13px;
            }
            .btn-primary {
                background: var(--azul-oscuro);
                color: var(--blanco);
                box-shadow: 0 2px 6px rgba(0,51,102,.2);
            }
            .btn-primary:hover {
                background: var(--azul-medio);
            }
            .btn-secondary {
                background: var(--blanco);
                color: var(--gris-800);
                border: 1.5px solid var(--gris-300);
            }
            .btn-secondary:hover {
                background: var(--gris-100);
            }
            .btn-danger {
                background: var(--rojo);
                color: var(--blanco);
            }
            .btn-danger:hover {
                background: #a93226;
            }
            .btn-sm {
                padding: 6px 12px;
                font-size: 12.5px;
            }
            .btn-icon {
                padding: 7px 9px;
            }

            /* ── BADGES/ESTADOS ── */
            .badge {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                padding: 3px 9px;
                border-radius: 12px;
                font-size: 11.5px;
                font-weight: 600;
                letter-spacing: .3px;
            }
            .badge-vigente  {
                background: var(--verde-claro);
                color: var(--verde);
            }
            .badge-vencido  {
                background: var(--rojo-claro);
                color: var(--rojo);
            }
            .badge-cancelado{
                background: var(--gris-200);
                color: var(--gris-600);
            }
            .badge-pendiente{
                background: var(--amarillo-claro);
                color: var(--amarillo);
            }
            .badge i {
                font-size: 9px;
            }

            @keyframes fadeOverlay {
                from {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }
            @keyframes modalIn {
                from {
                    opacity: 0;
                    transform: translateY(-16px) scale(.97);
                }
                to {
                    opacity: 1;
                    transform: none;
                }
            }
            @keyframes toastIn {
                from {
                    opacity: 0;
                    transform: translateX(20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }

            @media (max-width: 768px) {
                .sidebar {
                    transform: translateX(-100%);
                }
                .sidebar.open {
                    transform: translateX(0);
                }
                .main-area {
                    margin-left: 0;
                }
                .form-row.cols-2, .form-row.cols-3 {
                    grid-template-columns: 1fr;
                }
            }
        </style>
    </head>
    <body>

        <!-- ══ SIDEBAR ══ -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar__brand">
                <div class="logo-row">
                    <div class="logo-icon"><i class="fas fa-landmark"></i></div>
                    <h2>Registraduría<br>de Nobsa</h2>
                </div>
                <p>Panel Administrativo</p>
            </div>

            <nav class="sidebar__nav">
                <div class="nav-label">Módulos</div>
                <a href="${pageContext.request.contextPath}/admin/ciudadanos"
                   class="nav-item ${activeSection == 'ciudadanos' ? 'active' : ''}">
                    <i class="fas fa-users"></i> Ciudadanos
                </a>
                <a href="${pageContext.request.contextPath}/admin/documentos"
                   class="nav-item ${activeSection == 'documentos' ? 'active' : ''}">
                    <i class="fas fa-id-card"></i> Documentos
                </a>

                <div class="nav-label">Electoral</div>
                <a href="${pageContext.request.contextPath}/admin/zonas"
                   class="nav-item ${activeSection == 'zonas' ? 'active' : ''}">
                    <i class="fas fa-map-marked-alt"></i> Zonas de Votación
                </a>
                <a href="${pageContext.request.contextPath}/admin/mesas"
                   class="nav-item ${activeSection == 'mesas' ? 'active' : ''}">
                    <i class="fas fa-table"></i> Mesas de Votación
                </a>

                <div class="nav-label">Consultas</div>
                <a href="${pageContext.request.contextPath}/consulta-mesa"
                   class="nav-item" target="_blank">
                    <i class="fas fa-search"></i> Vista Pública
                    <i class="fas fa-external-link-alt" style="font-size:10px;margin-left:auto;opacity:.5;"></i>
                </a>
            </nav>

            <div class="sidebar__footer">
                <div class="user-row">
                    <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                    <div>
                        <div class="user-name">Administrador</div>
                        <div class="user-role">Registraduría Nobsa</div>
                    </div>
                </div>
                <a href="${pageContext.request.contextPath}/admin/logout" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Cerrar sesión
                </a>
            </div>
        </aside>

        <!-- ══ ÁREA PRINCIPAL ══ -->
        <div class="main-area">
            <!-- TOPBAR -->
            <div class="topbar">
                <div class="breadcrumb">
                    <a href="${pageContext.request.contextPath}/admin/dashboard">Inicio</a>
                    <i class="fas fa-chevron-right"></i>
                    <span class="current">${pageTitle}</span>
                </div>
                <div class="topbar-right">
                    <a href="${pageContext.request.contextPath}/" class="btn-public" target="_blank">
                        <i class="fas fa-external-link-alt"></i> Vista ciudadano
                    </a>
                </div>
            </div>

            <!-- ── CONTENIDO DE CADA MÓDULO SE INYECTA AQUÍ ── -->
            <%-- jsp:include o content blocks de cada vista --%>
