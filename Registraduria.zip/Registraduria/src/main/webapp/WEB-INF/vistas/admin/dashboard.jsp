<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="pageTitle" value="Inicio" scope="request"/>
<c:set var="activeSection" value="dashboard" scope="request"/>
<%@ include file="/WEB-INF/vistas/admin/adminLayout.jsp" %>

<style>
    .page-content {
        padding: 28px;
    }
    .welcome-bar {
        margin-bottom: 28px;
    }
    .welcome-bar h2 {
        font-family: var(--font-display);
        font-size: 24px;
        font-weight: 700;
        color: var(--negro);
    }
    .welcome-bar p {
        font-size: 14px;
        color: var(--gris-600);
        margin-top: 3px;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 16px;
        margin-bottom: 28px;
    }
    .stat-card {
        background: var(--blanco);
        border: 1px solid var(--gris-200);
        border-radius: 10px;
        padding: 20px 22px;
        box-shadow: var(--shadow-sm);
        display: flex;
        align-items: center;
        gap: 16px;
        text-decoration: none;
        color: inherit;
        transition: box-shadow .15s, transform .15s;
    }
    .stat-card:hover {
        box-shadow: var(--shadow-md);
        transform: translateY(-2px);
    }
    .stat-card .stat-icon {
        width: 46px;
        height: 46px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    .stat-card .stat-icon i {
        font-size: 20px;
    }
    .stat-card.card-azul .stat-icon  {
        background: var(--azul-claro);
    }
    .stat-card.card-azul .stat-icon i {
        color: var(--azul-oscuro);
    }
    .stat-card.card-verde .stat-icon  {
        background: var(--verde-claro);
    }
    .stat-card.card-verde .stat-icon i {
        color: var(--verde);
    }
    .stat-card.card-dorado .stat-icon  {
        background: var(--dorado-claro);
    }
    .stat-card.card-dorado .stat-icon i {
        color: var(--dorado);
    }
    .stat-card.card-gris .stat-icon   {
        background: var(--gris-200);
    }
    .stat-card.card-gris .stat-icon i {
        color: var(--gris-600);
    }
    .stat-card .stat-info .stat-value {
        font-family: var(--font-display);
        font-size: 28px;
        font-weight: 700;
        color: var(--negro);
        line-height: 1;
    }
    .stat-card .stat-info .stat-label {
        font-size: 12px;
        color: var(--gris-600);
        margin-top: 3px;
    }

    .alertas-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-bottom: 28px;
    }
    .alerta-card {
        border-radius: 8px;
        padding: 14px 18px;
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 13.5px;
        font-weight: 500;
    }
    .alerta-card i {
        font-size: 18px;
        flex-shrink: 0;
    }
    .alerta-card .alerta-num {
        font-size: 20px;
        font-weight: 700;
        margin-right: 4px;
    }
    .alerta-card a {
        color: inherit;
        text-decoration: underline;
        font-weight: 600;
    }
    .alerta-rojo  {
        background: var(--rojo-claro);
        color: var(--rojo);
        border: 1px solid #F1948A;
    }
    .alerta-amar  {
        background: var(--amarillo-claro);
        color: var(--amarillo);
        border: 1px solid #F6D860;
    }
    .alerta-gris  {
        background: var(--gris-100);
        color: var(--gris-600);
        border: 1px solid var(--gris-200);
    }

    .section-title {
        font-size: 14px;
        font-weight: 700;
        color: var(--gris-800);
        margin-bottom: 14px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .section-title a {
        font-size: 12px;
        font-weight: 500;
        color: var(--azul-medio);
        text-decoration: none;
    }
    .section-title a:hover {
        text-decoration: underline;
    }
    .mini-table-card {
        background: var(--blanco);
        border: 1px solid var(--gris-200);
        border-radius: 8px;
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }
    .mini-table-card table {
        width: 100%;
        border-collapse: collapse;
    }
    .mini-table-card thead th {
        padding: 9px 16px;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: .8px;
        text-transform: uppercase;
        color: var(--gris-600);
        background: var(--gris-100);
        border-bottom: 1px solid var(--gris-200);
        text-align: left;
    }
    .mini-table-card tbody td {
        padding: 10px 16px;
        font-size: 13.5px;
        border-bottom: 1px solid var(--gris-200);
    }
    .mini-table-card tbody tr:last-child td {
        border-bottom: none;
    }
    .mini-table-card tbody tr:hover {
        background: var(--azul-claro);
    }

    .accesos-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
        margin-bottom: 28px;
    }
    .acceso-btn {
        background: var(--blanco);
        border: 1px solid var(--gris-200);
        border-radius: 8px;
        padding: 16px;
        text-decoration: none;
        color: var(--negro);
        display: flex;
        align-items: center;
        gap: 12px;
        transition: box-shadow .15s, background .15s;
        box-shadow: var(--shadow-sm);
    }
    .acceso-btn:hover {
        background: var(--azul-claro);
        box-shadow: var(--shadow-md);
    }
    .acceso-btn i {
        color: var(--azul-medio);
        font-size: 20px;
        width: 24px;
        text-align: center;
    }
    .acceso-btn .acc-label {
        font-size: 14px;
        font-weight: 600;
    }
    .acceso-btn .acc-sub {
        font-size: 12px;
        color: var(--gris-600);
    }

    @media (max-width: 900px) {
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    @media (max-width: 600px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }
        .alertas-row {
            grid-template-columns: 1fr;
        }
        .accesos-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="page-content">
    <div class="welcome-bar">
        <h2>Bienvenido, Administrador</h2>
        <p>Panel de gestión de la Registraduría Municipal de Nobsa · Boyacá</p>
    </div>

    <div class="stats-grid">
        <a href="${pageContext.request.contextPath}/admin/ciudadanos" class="stat-card card-azul">
            <div class="stat-icon"><i class="fas fa-users"></i></div>
            <div class="stat-info">
                <div class="stat-value">${totalCiudadanos}</div>
                <div class="stat-label">Ciudadanos registrados</div>
            </div>
        </a>
        <a href="${pageContext.request.contextPath}/admin/documentos" class="stat-card card-verde">
            <div class="stat-icon"><i class="fas fa-id-card"></i></div>
            <div class="stat-info">
                <div class="stat-value">${totalDocumentos}</div>
                <div class="stat-label">Documentos expedidos</div>
            </div>
        </a>
        <a href="${pageContext.request.contextPath}/admin/zonas" class="stat-card card-dorado">
            <div class="stat-icon"><i class="fas fa-map-marked-alt"></i></div>
            <div class="stat-info">
                <div class="stat-value">${totalZonas}</div>
                <div class="stat-label">Zonas de votación</div>
            </div>
        </a>
        <a href="${pageContext.request.contextPath}/admin/mesas" class="stat-card card-gris">
            <div class="stat-icon"><i class="fas fa-table"></i></div>
            <div class="stat-info">
                <div class="stat-value">${totalMesas}</div>
                <div class="stat-label">Mesas habilitadas</div>
            </div>
        </a>
    </div>

    <div class="alertas-row">
        <c:choose>
            <c:when test="${documentosVencidos > 0}">
                <div class="alerta-card alerta-rojo">
                    <i class="fas fa-times-circle"></i>
                    <span>
                        <span class="alerta-num">${documentosVencidos}</span>
                        documento(s) <strong>vencido(s)</strong>.
                        <a href="${pageContext.request.contextPath}/admin/documentos?estado=vencido">Ver</a>
                    </span>
                </div>
            </c:when>
            <c:otherwise>
                <div class="alerta-card alerta-gris">
                    <i class="fas fa-check-circle"></i>
                    <span>Sin documentos vencidos. Todo en orden.</span>
                </div>
            </c:otherwise>
        </c:choose>

        <c:choose>
            <c:when test="${ciudadanosSinMesa > 0}">
                <div class="alerta-card alerta-amar">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>
                        <span class="alerta-num">${ciudadanosSinMesa}</span>
                        ciudadano(s) <strong>sin mesa asignada</strong>.
                        <a href="${pageContext.request.contextPath}/admin/ciudadanos?sinMesa=true">Ver</a>
                    </span>
                </div>
            </c:when>
            <c:otherwise>
                <div class="alerta-card alerta-gris">
                    <i class="fas fa-check-circle"></i>
                    <span>Todos los ciudadanos tienen mesa asignada.</span>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <%-- BONUS: alerta documentos próximos a vencer --%>
    <c:if test="${documentosProxVencer > 0}">
        <div class="alerta-card alerta-amar" style="margin-bottom:24px;">
            <i class="fas fa-clock"></i>
            <span>
                <span class="alerta-num">${documentosProxVencer}</span>
                documento(s) vencen en los próximos <strong>30 días</strong>.
                <a href="${pageContext.request.contextPath}/admin/documentos?proxVencer=true">Revisar</a>
            </span>
        </div>
    </c:if>

    <div class="section-title">Accesos Rápidos</div>
    <div class="accesos-grid" style="margin-bottom:28px;">
        <a href="${pageContext.request.contextPath}/admin/ciudadanos" class="acceso-btn"
           onclick="/* abre modal crear */">
            <i class="fas fa-user-plus"></i>
            <div><div class="acc-label">Registrar Ciudadano</div><div class="acc-sub">Agregar nuevo ciudadano</div></div>
        </a>
        <a href="${pageContext.request.contextPath}/admin/documentos" class="acceso-btn">
            <i class="fas fa-file-export"></i>
            <div><div class="acc-label">Expedir Documento</div><div class="acc-sub">Nueva cédula o tarjeta</div></div>
        </a>
        <a href="${pageContext.request.contextPath}/" target="_blank" class="acceso-btn">
            <i class="fas fa-search"></i>
            <div><div class="acc-label">Consulta Pública</div><div class="acc-sub">Vista del votante</div></div>
        </a>
        <a href="${pageContext.request.contextPath}/admin/mesas" class="acceso-btn">
            <i class="fas fa-table"></i>
            <div><div class="acc-label">Gestionar Mesas</div><div class="acc-sub">Zonas y mesas electorales</div></div>
        </a>
    </div>

    <div class="section-title">
        Últimos Ciudadanos Registrados
        <a href="${pageContext.request.contextPath}/admin/ciudadanos">Ver todos →</a>
    </div>
    <div class="mini-table-card">
        <table>
            <thead>
                <tr>
                    <th>Cédula</th>
                    <th>Nombre</th>
                    <th>Vereda / Barrio</th>
                    <th>Mesa</th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty ultimosCiudadanos}">
                        <tr><td colspan="4" style="text-align:center;color:var(--gris-400);padding:20px;">Sin registros aún.</td></tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="c" items="${ultimosCiudadanos}">
                            <tr>
                                <td><span style="font-family:monospace;font-size:13px;">${c.numeroDocumento}</span></td>
                                <td><strong>${c.nombres} ${c.apellidos}</strong></td>
                                <td>${c.veredaBarrio}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${not empty c.idMesa}">
                                            <span class="badge badge-vigente"><i class="fas fa-check"></i> Mesa ${c.idMesa}</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-pendiente"><i class="fas fa-clock"></i> Sin asignar</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
